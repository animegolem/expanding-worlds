The chrome button — THE shared small-button primitive, and since the kit 1.1 ruling THE one button geometry (registry lead: TagPanel, SearchPanel, RestoreDialog, and SettingsView must use this, not hand-rolled lookalikes).

```jsx
<Button onClick={fn}>Restore</Button>
<Button variant="accent">Add to library</Button>
<Button variant="ghost">not now</Button>
<Button disabled>Empty Trash</Button>
```

- ONE geometry (kit 1.1 ruling): raised surface, 1px control border, 5px radius; hover lightens one surface step; disabled rests at 0.4; focus = the 2px `--ew-focus-ring` outline. The 4px dialog button and the 6px variant are retired — color variants ride the one shape.
- `accent` = the committed/primary act; `ghost` = borderless quiet act.
- Danger styling is per-use: pass `style={{ color: 'var(--ew-danger-muted)', borderColor: 'var(--ew-danger-border)' }}` — only destructive verbs wear it.
