import React from 'react';

/** Text input — THE shared input primitive, two variants and only two
 * (kit 1.1 ruling): standard 5px = configure (settings, dialogs,
 * rename); pill=true = filter-in-place (search fields, tag fields,
 * facet bars). Input surface, strong border; focus = the shared 2px
 * --ew-focus-ring outline, both variants — never the browser default.
 * NEVER back with <datalist> — completions are custom lists. */
export function TextInput({ value, placeholder, pill, prefix, onChange, style }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
      {prefix && <span style={{ color: 'var(--ew-text-muted)', fontWeight: 600, fontSize: '0.78rem' }}>{prefix}</span>}
      <input
        type="text"
        value={value}
        placeholder={placeholder}
        onChange={onChange ? (e) => onChange(e.target.value) : undefined}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          width: '9rem',
          boxSizing: 'border-box',
          padding: '0.18rem 0.55rem',
          background: 'var(--ew-surface-input)',
          color: 'var(--ew-text)',
          border: '1px solid var(--ew-border-strong)',
          borderRadius: pill ? 999 : 5,
          font: 'inherit',
          fontSize: '0.78rem',
          fontFamily: 'var(--ew-font-ui)',
          outline: focus ? '2px solid var(--ew-focus-ring)' : 'none',
          outlineOffset: 1,
          ...style,
        }}
      />
    </span>
  );
}
