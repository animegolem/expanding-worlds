import React from 'react';

/** Chrome button — THE one button geometry (kit 1.1 ruling): raised
 * surface, 1px control border, 5px radius, hover lightens one surface
 * step, disabled .4. Color variants ride the one shape — 'accent' =
 * committed act; 'ghost' = borderless quiet act. Focus: the shared
 * 2px --ew-focus-ring outline (never the browser default). */
export function Button({ children, variant = 'default', disabled, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const [focus, setFocus] = React.useState(false);
  const accent = variant === 'accent';
  const ghost = variant === 'ghost';
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onFocus={(e) => setFocus(e.target.matches(':focus-visible'))}
      onBlur={() => setFocus(false)}
      style={{
        padding: '0.2rem 0.7rem',
        background: accent
          ? 'var(--ew-accent)'
          : ghost
            ? hover && !disabled ? 'var(--ew-surface-raised)' : 'transparent'
            : hover && !disabled ? 'var(--ew-surface-control-hover)' : 'var(--ew-surface-raised)',
        color: accent ? 'var(--ew-on-accent)' : 'var(--ew-text)',
        border: ghost ? 'none' : `1px solid ${accent ? 'var(--ew-accent)' : 'var(--ew-border-control)'}`,
        borderRadius: 5,
        outline: focus ? '2px solid var(--ew-focus-ring)' : 'none',
        outlineOffset: 1,
        fontSize: '0.8rem',
        fontFamily: 'var(--ew-font-ui)',
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        ...style,
      }}
    >
      {children}
    </button>
  );
}
