The text input — THE shared input primitive (registry lead: TagPanel, SearchPanel, RestoreDialog, and SettingsView must use this, not hand-rolled fields).

```jsx
<TextInput pill prefix="⌕" placeholder="filter…" value={q} onChange={setQ} />
<TextInput prefix="#" placeholder="add tag" />
```

- Input surface + strong border; exactly two variants (kit 1.1 ruling): standard 5px = configure (settings, dialogs) · `pill` = filter-in-place (search, tags, facet bars) — `pill` is grammar, not styling freedom. Focus = the 2px `--ew-focus-ring` outline on both, never the browser default. `prefix` renders the leading glyph outside the field.
- NEVER back it with `<datalist>` (Electron segfault) — completions are custom lists.
- For the gallery/board search control with pill crystallization, use `SearchTrack` instead.
