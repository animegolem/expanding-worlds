# Design letter — home canvas kit push

*To the lead, from the design session of 2026-07-11 → 12. Companion to
the home-canvas-kit artifacts (kit DC, grammar page, wireframes,
KIT-PREFLIGHT, GR-5). Everything here is clickable in
`Home Canvas UI Kit.dc.html`; the wireframe ids (1a, 4d, 5a…) link into
`Home Canvas Wireframes.dc.html`. Items marked RULED were decided in
session; items marked FOR REVIEW want your cosign or veto.*

## Rulings made this session

1. **Reservation frame + charm halo (1a, 1b) — RULED.** Four named
   bands as chrome.css tokens (kit-1.4 proposal); every floating
   surface clamps inside frame + 24px gutter; overlays pad by charm
   halo (card + 12px + charm height), never card edge. Every kit ships
   an edges specimen; preflight F-section enforces.
2. **Dock stays pure + one defaults row (1d) — RULED.** Tool defaults
   (what the NEXT thing gets) in one kit-drawn row above the dock;
   restyle of a selection lives on the charm bar. The shipped stacking
   contextual rows (~22 word-buttons) retire entirely.
3. **Shape flyout (2a) — RULED.** One slot, hold ~300ms, flyout centers
   on the armed slot with a pointer tail; grid palette (2b) is the
   graduation path if the 3D family lands.
4. **Selection/transform touch dialect (3a+3b) — RULED, GR-5 §1–4.**
   Outline-as-affordance with a fat hit band; corner dots as the
   touch-density teaching layer (smallest amendment to "no handles,
   ever"); gesture table incl. long-press = context menu. GR-5 §5–6
   (fade-clock wake sources, teaching channel) are PROPOSALS for you.
5. **Board menu → MenuPopover, three doors (4a+4b) — RULED.** Same
   §6.7 verbs; strip ❖ trigger · right-click ground · long-press
   ground. Swatch row replaces the OS color input. "BG from file…" →
   "bg from image…".
6. **Containers everywhere; strip gradient retired (4d) — RULED,
   supersedes decision-01.** The signature spot and ❖ live in chrome
   containers (surface/border/radius 7) on every platform; the smoky
   hover gradient goes away; the band stays as drag region. Rationale:
   one chrome family with dock/rail, identical desktop/touch, and it
   fixes the bare form's optical-centering bug class for free.
7. **Arrange rides the selection (5a) — RULED.** Multi-select charm
   bar gains ⌗; anchored glyph-grid panel (align / spread / pack /
   equalize, four named sections); z-order + group/lock/hide are
   context-menu rows; chords survive; panel centers on the ⌗ charm.

## Smaller calls baked into the kit (FOR REVIEW, cheap to reverse)

- **Board trigger glyph ❖** ("the board's parts") — over ⊡ / ▦; ⬚ is
  disqualified (frame tool's face). Tooltip carries the name.
- **Defaults-row scope label dropped.** The row briefly said
  "next text:" / "next shape:" to disambiguate tool-defaults from
  selection-restyle; we cut it for cleanliness — the two-homes split
  should carry the meaning. Watch the tester: if defaults get read as
  "restyle selection", the label (or `new text:`) comes back.
- **Ink row = last-3 colors + picker block.** The picker (anchored off
  its block, pointer tail) is kit-drawn: SV square + hue bar + hex
  entry + last-12 grid. No OS color dialog anywhere.
- **Eyedropper ⊙ added beside the dock** — samples any board color as
  the ink. New tool, needs your yes (and a real glyph decision).
- **Font picker-list** replaces the dock's native `<select>`
  (curated stacks first, installed fonts on demand, per the shipped
  lazy-load pattern). Kills the last beta native in this surface.
- **The signature pin** is the ratified globe-lined red PinGlyph in
  the kit, cap-height, beat-ready — not a stand-in teardrop.
- **Identity corner ◎ (wireframes 6b) — restored affordance.** Lower-
  left button opens the current canvas's self: profile slot (drop /
  paste / browse — the world's face on home), note excerpt + ✎, and
  every place its image lives with ⌖ flights. Glyph-only over the
  thumb-chip (6a) because the path bar already names the canvas.
  Claims a reserve-identity corner in the frame. RULED in session:
  this panel IS the canonical "where does this live" surface (the
  note panel's ⌖ list defers to it); for a non-canvas node the same
  panel likely opens from a charm-bar verb — to be drawn with the
  note-paper kit, watch for tension there. Drop-on-◎ rejected
  (unintuitive) — the drop target is the panel's profile slot only.

## Known debts / not drawn yet

- Arrange panel + ⌗ charm are ruled and in grammar but NOT wired in
  the kit yet (waiting on multi-select in the demo board).
- Charm-bar clamping at frame edges is specified, not demonstrated —
  the demo nodes sit mid-board.
- GR-5 §5–6 need your ruling before any kit depends on them.
- Anchored-shift measurement in the kit DC re-measures on a timer
  after mount (async component load); fine for a kit, not a pattern
  for the app.

## Suggested review order

Open the kit → arm T (defaults row + font list) → arm ▭ twice (flyout
on the slot) → click ❖ (board menu, paint a swatch) → click a node
(charm bar) → toggle `showReservations` in tweaks → read GR-5 §5–6.


## Addendum — note paper kit (same session)

8. **Note paper postures (wireframes t1–t3) — RULED.** Hardware law
   per The Two Materials: rings = bound · push pin (angled, punching
   through) = planted in the world · tape (top-center, translucent) =
   on your glass · torn edge always on the side the page actually
   separated from. Whisper-strip verbs on paper (1a) — nothing
   chrome-colored rides the page; origin as paper-toned caption.
9. **Open is a flight (3a) — RULED.** ✎ flies the camera until
   image + page fill the viewport; esc flies back exactly. Bound-
   beside pages share the image's EXACT height at every viewport
   (width may run wider). Detach = pin-to-world (3b, full board-
   object grammar); tape-to-glass (3c) kept for travel. Rebind = one
   verb, one undo, from any posture.
10. **Zoom ruler (t2 2a) — proposed as a mandatory kit specimen**
   (preflight E gains a rung-check); the ✎ micro-glyph rung (2b) was
   considered and rejected — the ruled edge stroke stays.

Artifacts: Note Paper UI Kit.dc.html (all postures + flight live),
Note Paper Grammar.dc.html, Note Paper Wireframes.dc.html, preflight
filled (debts: edges specimen, touch density pass, in-kit zoom ruler,
centered editor). Unblocks AI-IMP-194. Motion-ledger artifact
deferred — the kit's tear/settle/flight beats are its first entries.


## Addendum 2 — gallery sweep (same session)

11. **Gallery = adoption, not new grammar — RULED.** Kit components
    replace every hand-rolled control (Segmented, FacetChip, pill
    TextInput + menu-tier completion list, Buttons); facet row wraps,
    never clips. Completes One-voice 1.2.
12. **Arrange-by carries its grouping — RULED.** date → time bands
    (mono caption + hairline, content-register); name → letter
    headers only past ~24 items; size → flat gradient, never banded.

Artifacts: Gallery UI Kit.dc.html (live facets, grouped grid,
selection action bar), Gallery Grammar.dc.html (short — inheritance
noted), preflight filled.

## Addendum 3 — pin/globe unification check (same session)

13. **One pin, one globe — VERIFIED + FIXED.** The canonical pin is
    silhouette iv with the carved-red MERIDIAN HEAD — the head is a
    globe ("pinning worlds in your world", echoing app icon 5a).
    Audit: home-canvas signature pin was correct; the note-paper push
    pin and motion-ledger pin had dropped the meridian head — both
    restored. Standing rule: the bare teardrop never ships; every pin
    wears the globe head. Bookmark menu rows wear small painted
    globes in place of dots (Signature Pin Changes #07) — lands with
    the bookmark-menu kit.

## Addendum 4 — outliner kit review + lens wiring audit

14. **Outliner kit retrofit (review pass).** The ▤ kit predated the
    reservation frame: its takeover sat at inset:16px and drew no
    rail. Retrofitted: sheet now clamps to the frame + gutter and the
    charm rail renders at its ruled spot (outline active). Already
    conformant from v1.1: untagged facet + calm-badge rule, three-door
    verb inventory, MenuPopover context menu, touchMode density,
    esc/✕ twins. Remaining debts: the ▤ preview pane should adopt the
    reading-flight verb ("open" flies, per note-paper §3) — currently
    a beat stub; and the kit predates KIT-PREFLIGHT (unfilled).

15. **Lens wiring audit — one lens, four surfaces, two gaps.**
    The lens grammar (tag hit = note-orange ring, miss dims ~0.35,
    view-state until dropped) is wired in: OUTLINER ✓ (tag chips
    engage it; active-lens ✕ chip in the bar). GALLERY — correct to
    NOT lens: retrieval filters (removes), it doesn't highlight;
    ruled as-is. Gaps: (a) HOME CANVAS — board placements never ring:
    ⌖ fly-to beats say "the lens rings the placement" but no kit
    draws that arrival ring on a NodeCard; NodeCard already has the
    `hit` prop — wiring, not design. (b) NOTE PAPER — tag chips on
    the page and wiki-link hover should be lens doors (§4.8/§7.5 one
    grammar); currently inert in the kit. Both are small wires, both
    should land before the click-through shell so lens reads as ONE
    system across surfaces.


## Addendum 5 — search palette + lens wires (same session)

16. **Universal search palette (Search Wireframes 1a) — RULED.**
    Centered over the scrimmed board (board stays visible — search is
    a layer, not a place), top edge flush with the rail band. Kind-
    grouped results whose HEADERS name their ↵ verb (boards dive ·
    notes open the panel · tags open the tag panel · images show
    their nodes · canvas text flies to the words). Leading # flips to
    tag mode: booru-shaped AND-only, committed tags crystallize into
    colored pills (✕ each; backspace eats the last). Trash excluded
    by default. RFC DELTA needing your cosign: §8.3 anchors search in
    the ⌕ charm's panel — the centered palette supersedes that for
    the keyboard door; rail-⌕ becomes the second door to the SAME
    surface (the board-menu multi-door pattern).
17. **Lens wires landed (audit item 15).** Home canvas: the tags
    charm now engages the lens — hits ring note-orange via NodeCard's
    hit prop, misses dim, active-lens ✕ chip at top; note paper: the
    page's tag chips are lens doors (beat names the contract). One
    lens, every surface, before the click-through shell.

Artifacts: Search Wireframes.dc.html, Search UI Kit.dc.html (live
palette: kind groups, tag pills, empty states, keyboard walk),
preflight filled. Home Canvas + Note Paper kits updated in place.


## Addendum 6 — graph takeover (same session)

18. **Graph kit (§14.2, first drawing ever) — built to spec.** ⊛
    takeover in the reservation frame; live force layout you can
    grab; wiki links the ONLY edges; pure notes as palette dots,
    placed art as the art itself (LOD); orphans dashed-warn-ringed,
    unplaced dashed-white; the three ruled filters live; activation
    flies (placed) or opens the note (unplaced); trash + decoration
    lines excluded and the footer says so. Open for you: does an
    asymptotically-settling force sim violate "no ambient motion"?
    (My read: no — it's world physics, not chrome; it settles.)

Remaining undesigned surface: the ☰ menu mode. Everything else on
the rail now has a kit.

## Addendum 8 — coverage push to completion (same session)

21. Built down the SCOPE-COVERAGE list: tag panel (live lens) · trash
    view (list/grid + arrange-by grouping, burn ceremony) · bookmark
    menu (pin beat gates the cascade, globes for dots) · condition
    panel (⚠ ongoing-only, dismiss-all, perch leaves with its last
    condition) · world picker (world cards wear their ◎ faces, "you
    are here") · source panel (scope segmented, browse-only
    everything, pull-by-copy, basic tag filter) · menu ☰ · graph ⊛ ·
    search grammar page · outliner reading-flight verb · graph
    tap-to-name · selection restyle ◧ panel.
22. **For your ruling — drag OUT of the search palette.** Owner
    instinct: an image result should drag from the palette onto the
    board as a placement (palette folds mid-drag, drop = ordinary
    place flow). Grammar-consistent (drag = place, everywhere) but
    unruled: does search stay a pure departure surface, or is it also
    a source? If cosigned it applies to the tag panel's rows too.
23. **The ground menu (extends ruling 4b).** Right-click / long-press
    on empty board now opens ONE menu: a HERE section (paste · text ·
    pin · shape · frame — creation lands at the click point, plain-key
    shortcuts in mono) above a board… row that opens the ❖ menu. No
    arrange verbs — arrangement requires a selection and lives on the
    charm bar. Wired in the home canvas kit.


## Addendum 7 — tag panel + trash view (same session)

19. **Tag panel (§4.8) — built to spec.** One-tag field with tab
    completion; header lens toggle LIVE (matches keep color + warn
    ring, board dims to ~0.18; esc drops lens before panel); §7.4
    row grammar with per-row ✎ and ⌖ (cross-canvas flight = §8.1
    navigation event); three doors named in the footer. Owner note:
    multi-tag search is wanted eventually — cosigned that it's a
    backend unlock, not a UX change (the search palette's AND pills
    are the recorded grammar).
20. **Trash view (§9) — built.** The recovery home: restore is the
    headline verb per row and bulk; Empty Trash is the app's ONE
    destructive ceremony — confirm states impact as fact and the
    burn beat plays only here. Rows carry where-it-lived so restore
    lands somewhere ruled.


## Addendum 9 — caption card + editor polish (same session)

24. **Caption card = the museum label, made of paper.** Alf's bond
    request resolved skeuomorphically: the caption is a small PAPER
    card (the desk's own material) slipped out from under the print,
    slightly askew, dark warm ink, standing up with a one-shot POP
    beat when it's born (280ms, whisper of overshoot). Tweak keeps
    placard/framed/floating for comparison; card is the default.
    Pop joins the motion ledger next revision.
25. **Captions in the outline — PROPOSED amendment.** Owner: caption
    text should show as row meta on a node's placement rows — it's
    how you tell WHICH placement you're looking at. Consistent with
    §4.5's asymmetry if drawn as display meta (the caption still
    never becomes an outline ENTRY; search still points at the
    image). Needs your cosign; outliner kit picks it up after.
26. **Big editor polish:** whisper strip (B · I · link · [[wiki]] ·
    media), obsidian-style source⇄rendered toggle (source is the
    truth; rendered read-only, click to edit), centered faded
    subset hint on empty notes ("# ## ### — fold with tab").


## Addendum 10 — final pieces + amendments (session close)

27. **Selection & transform kit built** (GR-5 §1 live): 18px hit band
    on the outline — edge resizes, corner scales about the opposite
    corner, inside moves; hover just OUTSIDE a corner shows the
    rotate cursor and drags rotation about the center. First-
    selection coach chip, once ever.
28. **AMENDMENT — corner dots always-on.** Owner ruling: the 14px
    corner dots read better at BOTH densities; "touch density only"
    (GR-5 §1) is amended to "whenever selected". One less desktop/
    touch divergence.
29. **Caption card final form: the plaque** — cream face in a slim
    brushed-metal frame, layered 3D shadow, centered under its print
    as an invariant, narrower than the art, pop-up birth beat.
    ❝ belongs on the DS CharmBar (component amendment).

## Suggested review order (final)

home canvas (arm tools, flyout, ❖, ◎, ground right-click, lens,
select the shape → ◧/⌗ panels) → selection transform → note paper →
big editor → caption card → outliner → gallery → graph → search →
tag panel → trash → bookmark menu → condition panel → menu → world
picker → source panel → first run → motion ledger → GR-5.
