# Surface review — kit-drift and touch-readiness, ranked

*From the design session, 2026-07-10. A code sweep of the shipped
renderer chrome judged against three ideals: the kit (One-voice
control geometry 1.2, the beat ledger, chrome constraints), The Two
Materials, and the new requirement that every surface must have a
credible iPad answer (44px targets, no hover-dependence, no
cursor-only affordances). Companion to LIFECYCLE-INVENTORY.md — that
document grades behavior arcs; this one grades the drawn surface and
its input grammar. The owner's baseline interaction-rules pass merges
into this on the second pass. Sources read: Dock.svelte,
TitleStrip.svelte, SearchPanel.svelte, GalleryFacets.svelte,
GalleryActionBar.svelte, Toast/ui components, theme/typography
tokens; the rest graded from the lifecycle inventory, DESIGN-GAPS,
and the kit changelog where noted.*

**Three axes per surface:**
- **KIT-DRIFT** — geometry/tokens/components diverge from the ratified kit.
- **GRAMMAR-GAP** — the interaction shape was never drawn (kit silent), so the code improvised.
- **TOUCH-DEBT** — the surface has no iPad answer: hover-gated, cursor-sensed, sub-44px, or right-click/keyboard-only.

Grades: LOW · MODERATE · SEVERE per axis.

## Ranked: most divorced first

### 1. The Dock (+ its contextual rows) — SEVERE / SEVERE / SEVERE
The known worst (AI-IMP-189 already stalls at "kit silent") and the
code confirms it compounding:
- **Native controls in chrome:** `<input type=color>` (5 of them),
  `<select>` for the font picker, bare `type=number` fields — none of
  these have a kit drawing, none carry the uniform focus ring, and the
  OS color picker is a modal foreign body over the board.
- **Text-label verb soup:** the selection row is ~19 word-buttons
  ("Distribute H", "Eq. area", "To front"…) that wrap to 78vw — in
  practice a status strip, which §8 chrome rules say must not exist.
  This is also the arrange-discoverability hole (AI-IMP-198) wearing
  its visual symptom.
- **One-voice violations:** button radius 5px is right, but inputs sit
  at 4px, and the contextual rows stack as ad-hoc bars rather than the
  one anchored-popover physics.
- **Dead and disagreeing controls:** text tool shows stroke/weight/fill
  it never consumes (inventory S1); frame sort-on-drop vocabulary
  disagrees with the charm bar and goes stale (top-10 #9).
- **Touch:** tool buttons are 1.9rem (~30px); glyph-only buttons whose
  ONLY name is a hover tooltip; the shape flyout is a click-toggle
  today but its drawn future (AI-IMP-190) is Photoshop hold-to-pick —
  fine on touch (long-press) if drawn that way deliberately.

**Verdict:** the dock family needs the full drawing session 189 asked
for, now with a touch column: resting/hover/active AND pressed/long-
press, 44px grid, and a ruling on where the restyle rows live (the
kit's answer should probably be "in an anchored panel grown from the
selection, not stacked bars").

### 2. Canvas selection & transform grammar (cursor zones, charms, engagement fade) — LOW / MODERATE / SEVERE
The desktop grammar is ratified and good: thin outline, no handles,
cursor-as-affordance, hover census, one shared fade clock, tooltips
as the tutorial. Every one of those five load-bearing ideas is
cursor- or hover-dependent:
- No cursor on iPad → **zero transform affordance** (cursor zones are
  the affordance; handles are banned by ruling).
- Hint charms rest at 0.7 on hover-census — no hover exists.
- The engagement fade clock keys off pointer motion; touch idles
  differently (chrome would fade WHILE reading).
- Tooltips (name + shortcut) are the app's teaching channel — hover-
  only, so "the GUI is the tutorial" collapses silently on touch.
- Right-click context menus (ContextMenu.ts, 958 LOC of inventory)
  have no long-press mapping ruled anywhere.

**Verdict:** this is not restyle work — it needs a RULING-level
document: the touch dialect of the one grammar. Candidate shape: the
selection outline itself becomes the touch affordance (edge-drag =
resize, two-finger rotate, long-press = context menu, charm bar
carries what the cursor carried), and the fade clock gains a touch
definition (fade on scroll/pan, wake on tap). This should be drawn
once, centrally, in the owner's interaction-grammar pass — every
other surface inherits it. Flagging as the single highest-leverage
item in this review.

### 3. TitleStrip + Board menu — MODERATE / MODERATE / SEVERE
- The reveal is **cursor-Y sensed** (pointermove ≤46px) — on iPad the
  strip is unreachable except via the `always` setting; there is no
  drawn touch trigger (edge-swipe? persistent grab handle?). The
  `hover · always · never` setting needs a fourth answer or a touch
  default.
- The Board menu is hand-rolled rows (radius 4px buttons — pre-1.2
  geometry), a native color input, and a squared-corner dropdown that
  predates MenuPopover — it should BE a MenuPopover, anchored to its
  opener like everything else.
- BG edit mode's floating bar is the model citizen (persistent, not
  hover-gated) — keep it as the reference.

### 4. Gallery facets + action bar — MODERATE / LOW / MODERATE
The named 1.2 stragglers, confirmed:
- Hand-rolled segmented control and chips with local geometry instead
  of the kit's Segmented/FacetChip; completion menus at radius 6 (menu
  tier is 7); no uniform focus ring on the chip buttons.
- The action bar itself composes ui/Button correctly — closest to
  mechanical-sweep territory in this list.
- Touch: chips ~22px tall, completion rows ~24px; needs the 44px pass
  but the shapes survive.
- Behavior debt is tracked elsewhere (top-10 #1 undo bypass; G1 error
  state) — not re-counted here.

### 5. SearchPanel (⌕ / quick-open) — LOW / LOW / MODERATE
Good panel physics, anchored to its opener, custom completion list
(never datalist), Escape discipline. Gaps: no error state (top-10 #8
family, plus its unhandled rejection + type hole); rows ~24px with a
keyboard-first cursor — needs the touch pass (row height, and an
on-screen way to do what ArrowDown/Enter do); uses `scrollIntoView`.
Mostly inherits fixes from the central touch ruling.

### 6. SettingsView — MODERATE / LOW / LOW (from inventory + ratified doc)
The Settings Document is ratified, so remaining drift is adoption
mechanics: placeholder rows presenting no live control (Grid, Snap,
Border, Rounded), menuPlacement recording a value nothing reads, the
☰ Export row contradiction (top-10 #10). Fold handles + this-world
chips are drawn and waiting. Sheet physics (inset, translucent) are
inherently touch-friendly; row heights need the 44px audit.

### 7. NotePanel / paper family — MODERATE / SEVERE / MODERATE (from inventory + 194)
The Two Materials defines the material; the shipped panels use a
non-bound presentation the kit never drew (AI-IMP-194 is blocked on
exactly this). The caption card (DESIGN-GAPS) joins the same family.
Touch: panels are drag-positioned and pin/tear verbs are small chrome;
the paper surfaces themselves (reading/editing) are the most
naturally iPad-shaped thing in the app — worth designing the touch
story here EARLY because it is the likeliest delight.

### 8. OutlineView — (kit now exists)
The shipped view predates the new Outliner UI Kit (this project:
`Outliner UI Kit.dc.html` — desktop, with touchMode). Gap is total
but intentional; supersession, not drift. G6 holes (empty-doubles-as-
loading, tag filter stranding loose notes) fold into the rebuild.

## Cross-cutting touch findings (apply everywhere)

1. **No hover, no tutorial:** tooltips carry every control's name and
   shortcut. Touch needs a replacement teaching channel — candidates:
   long-press = tooltip chip, or a one-time "?" lens that labels all
   visible chrome. One ruling, app-wide.
2. **Right-click has no touch synonym ruled.** Long-press is the
   obvious candidate but collides with hold-to-pick (190) and drag
   initiation — needs one deliberate table: tap · double-tap ·
   long-press · drag · two-finger, per context.
3. **The 44px floor fails almost everywhere:** ~30px dock tools,
   ~22px chips, ~24px menu/list rows, 22px close buttons. Suggest the
   kit adds a DENSITY token pair (desktop compact / touch comfortable)
   rather than per-surface fixes — the Outliner kit's `touchMode` is
   the working prototype of exactly this.
4. **Keyboard-only exits:** Escape closes everything; several
   surfaces have no on-screen close (the search panel does, panels
   vary). Rule: every dismissible surface shows a ✕ on touch.
5. **Native inputs (`color`, `select`, `number`) leak OS chrome** at
   desktop AND produce giant OS sheets on iPad — the kit needs its own
   color swatch row + stepper + picker-list forms (the appearance
   charm's swatch popover is the precedent).
6. **Window-frame assumptions:** drag regions, traffic-light
   clearance, Linux window controls — all no-ops or wrong on iPad;
   the shell needs a per-platform chrome table.

## Where to cut UI kits next (desktop + touch pair each)

1. **Dock family** — biggest drift, ticket already waiting (189/190/198 fold in).
2. **Selection & charm grammar, touch dialect** — the central ruling everything else inherits (merge target for the owner's interaction-rules pass).
3. **Board menu → MenuPopover unification + TitleStrip touch trigger.**
4. **Note paper non-bound presentation + caption card** (194 unblocks; flagship N1).
5. **Gallery facet/action sweep** — mechanical, One-voice 1.2 completion.

## Resolved

(Move checked items here with a pointer to where they landed.)
