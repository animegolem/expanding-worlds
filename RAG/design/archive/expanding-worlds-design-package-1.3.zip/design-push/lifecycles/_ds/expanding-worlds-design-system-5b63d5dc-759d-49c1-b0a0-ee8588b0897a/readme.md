# Expanding Worlds — Design System

**Expanding Worlds** is an art-first, recursive reference-board / world-building **desktop app** (Electron + Svelte + WebGL canvas, Mac-lead). Think PureRef until you learn it nests: you place image references on an infinite board, any image can become a canvas of its own, notes attach to anything, wiki-links weave the world, and the global views (graph · outline · gallery) reveal you've been building a database all along. Product strategy is **composability** — each tool powerful but narrow, layers revealing one at a time. AI features are connectors, off by default.

One product/surface: **the desktop app**. No marketing site, no mobile.

## Sources (given for this pass)

- Codebase: mounted local folder `expanding-worlds/` (pnpm monorepo; `apps/desktop` is the app; renderer chrome is Svelte, canvas is WebGL). *(Mount dropped mid-pass 2026-07-07 after tokens were mirrored; re-attach via the Import menu for future codebase work.)*
- Canonical spec: `expanding-worlds/RAG/RFC-0001-Core-Note-Node-and-Canvas-Model.md` (rev 0.54) — domain semantics AND ratified design decisions (§5 invariants, §8 chrome, §20 decision log).
- Design pass entry points: `expanding-worlds/RAG/design/Design-letter-3.md`, and **Design-Artifacts v2.0** (2026-07-07) — extracted into `_src/v2-docs/` here: Style Guide v2 (the ■ TECH build contract; markdown twin at `STYLE-GUIDE.md`), UI Vision v2 (seven hero states), Usage Storyboard (20 sections), plus the exploration records (Icon · Settings · Gallery · Note Editor · Menus · First-Run documents), the two letters (Design-Team-Letter-1, Letter-to-the-Designer), and the **Note Lifecycle Document** (2026-07-07, → RFC §8.5 amendments). v1 artifacts remain in `_src/`.
- Current RFC text (rev 0.54) received from the dev team 2026-07-07 and reconciled — the v2 artifacts had been produced against a pinned, ~5-revs-stale worktree; the rev 0.50–0.54 deltas (void · §7.8 metadata card · frames ratified · rev 0.52 backups · rev 0.53 embeds/source_url) are landed here.
- **Authority when sources disagree: current RFC > Design-letter-3 > this kit > Design-Artifacts-v1.0** (historical feel only).
- Canonical token file: `apps/desktop/src/renderer/theme.css` → copied verbatim to `tokens/theme.css`, then extended with the ratified ■ TECH token additions (clearly fenced in the file). Compiled component CSS reference: `_src/compiled-app.css`.

## Load-bearing design constraints (not taste — guard-tested in CI)

- **Theme tokens only.** A guard test fails the build on raw hex/rgba outside theme.css. Every color is an `--ew-*` token first.
- **The window is the board.** Chrome is minimal, floating, and NEVER reflows the canvas. No docked sidebar, no status strip, no tab bar. Errors are toasts; ongoing conditions use the ⚠ perch charm.
- **One physics rule: panels grow out of the control you pressed.** Everything anchors to its opener.
- **Engagement cadence:** ALL chrome fades on ONE shared clock (4s idle → 240ms fade). Any element fading independently is a bug. Chrome rests at 0.92 opacity; hover lights that control alone to 1. Node hint charms rest at 0.7.
- **Shadow = screen-space; flat = world content.** Panels/menus/dock float with shadows; board cards render flat (tiny 3px radius, soft drop only).
- **Tooltip rule:** every hoverable control names itself + prints its shortcut, one chip style app-wide, ~500ms delay. The GUI is the tutorial.
- **Never the word "file" in copy** (§6.5). Verbs: "Replace image…", "Swap for…". Where a noun is unavoidable: "item" ("node" is a docs/graph word).
- **Never `<datalist>`** (Electron segfault); all completion UIs are custom lists.
- Themes: **dark (default) · light · glass** (Mac-only, falls back dark). Grid: lines · dots · none. Flat canvas colors: porcelain/putty/slate/ink.

## CONTENT FUNDAMENTALS

- **Sentence-case everything**; no title case in UI. Short, lowercase-leaning labels: "bookmark this board", "＋ bookmark this board", "esc to return", "in trash", "2 selected", "⌕ filter…".
- **No jargon nouns.** Never "file" (tester feared deleting pictures off his drive — the app copies bytes, never touches his files). "Item" when unavoidable. Verbs over nouns: "Replace image…", "Swap for…", "open as source".
- **First-run teaching copy** is plain and warm: "imports COPY bytes — your files are never touched; one item lives many places."
- **Confirmations state impact as fact**, not warning: "this will affect 35 placements — are you sure?" Passive teaching, not friction.
- **Tooltips** = name + printed shortcut ("Zoom to fit", "Pin N"). Menus print shortcuts in mono.
- **No emoji.** Glyphs are unicode symbols (see ICONOGRAPHY). No exclamation marks, no marketing voice anywhere in-app.
- Example world-content voice (seed/demo flavor): fantasy worldbuilding — "Chieftain of the warren beneath the Northern Reach… Owes Yorren a life-debt he resents."

## VISUAL FOUNDATIONS

- **Color:** near-black blue-grey chrome (`#17191d` family) with translucent surfaces (rgba alphas 0.82–0.97 by layer); one blue accent `#4a9df0` (light: `#2b6cb0`); desaturated semantic colors (danger `#b3403a`, warn `#e6b34a`). **Paper palette** — notes are light "paper" even in dark theme (`--ew-paper-*`: #fafafa surface, #ffffff page). **Node dot palette** (8, theme-independent world content): blue teal green gold orange red purple pink. **Flat canvas swatches** (6, theme-independent): user board paint. Link colors: bound blue, unresolved purple, broken red (+50% alpha underline decorations).
- **Type:** chrome is the system UI stack, small: 0.6–0.95rem. `ui-monospace` for shortcuts, tags (#tag), counts, zoom % (tabular-nums). Weight 600 for titles/active; no bolder. **The one webfont carve-out: note text is Maple Mono** (`--ew-font-editor`, bundled woff2 in `assets/fonts/`, OFL) — note panels, big editor, card excerpts, gallery text posts; NOWHERE in chrome. Editor scale: body .85rem/1.65, loud colored h1/h2/h3.
- **Spacing:** rem-based, compact — 0.15/0.2/0.25/0.3/0.35/0.4/0.45/0.6/0.75rem paddings. Controls ~30px (1.9–2rem) square.
- **Radii:** board cards 3px · buttons/menu rows 4–5px · controls 6–7px · charms/menus/toasts 7px · rail charms 8px · panels/dock/note panels 9px · action bars 10–12px · chips/facets 999px (full pill).
- **Shadows:** depth = layer grammar. Panels `0 6px 22px var(--ew-shadow)` · pinned `0 10px 30px` · menus `0 10px 28px` · board nodes `0 8px 22px rgba(0,0,0,.3)`. No inner shadows.
- **Borders:** 1px everywhere, token-tiered (border → strong → panel → control). Selection = 2px accent **outline** offset 3px (no drawn handles, ever). Lens/tag hits use the note-orange outline.
- **Backgrounds:** the canvas is `--ew-surface-solid` + grid (44px 1px lines, or 26px dots, or none). Takeover views use a darker flat `--ew-surface-overlay`-like field. Glass theme adds `backdrop-filter: blur(16–22px) saturate(1.15)`.
- **Motion:** fades and single pulses only, ease-out, 120–240ms. Perch pulse 700ms once. Panel-arrive pulse = focus-ring halo expanding to transparent. NO bounces, NO infinite loops.
- **Hover:** background lightens one surface step (`--ew-surface-hover`/`-raised`); chrome opacity 0.92 → 1. Press/active: accent fill + `--ew-on-accent` ink. Disabled: opacity 0.4–0.45.
- **Transparency/blur:** surfaces are translucent rgba over the board; blur only in glass theme.
- **Imagery:** user's own art is the hero; UI stays neutral. Placeholders (wireframes) use muted repeating diagonal stripes. Seed art: 9 public-domain-style generated PNGs (3 in `assets/seed/`).

## ICONOGRAPHY

- **No icon font, no SVG icon set, no emoji.** Icons are **unicode glyphs** chosen per-surface: rail ⧉ ⌕ ⊛ ⊞ ▤ ☰ · dock ⬚ T ▭ ◯ △ ➤ ✎ ╱ ↗ ⌁ ◉ − + ⤢ · charm bar ⌗ ⇋ ⇵ # ⊘ · misc ⌂ ⌖ ⇱ ✕ ⚠ ⚯ ◎ ↺ ▸ ‹ ›.
- Two **drawn hint charms** (page/frame) are built from bordered divs, not glyphs — see `components/board/`.
- **The six node object icons ARE designed** (Icon Document 2b family, ratified at the doctrine): star · pin · flag · heart · bolt · leaf — top-light gradients on the `--ew-obj-*` token pairs, restrained gloss, degrading to the plain dot below ~8px. SVG masters: `assets/icons/obj-*.svg`; live render: `ObjectIcon`. They are world content — the one glossy object admitted into chrome adjacency is the red pin ON the paper (panel pin control).
- The **pin** motif: "pins mean places, everywhere." The canonical pin is **silhouette iv** (`assets/icons/pin-canonical.svg`, 2026-07-07 signature pass) — the flat 50/50/50/0 teardrop is retired wherever pins mean places; components still drawing it await the sweep.
- One inline-SVG exception: the rotate cursor (in `tokens/theme.css`, a cursor bitmap, not chrome).
- **There is no logo or brand mark** in the sources. Render "Expanding Worlds" in plain type where a mark would go. Do not invent one.

## Index

- `styles.css` — global entry (imports the four token files below).
- `tokens/theme.css` — the canonical `--ew-*` palette, 3 themes (verbatim from app) + the fenced design-pass additions (frame region, void, paper materials, object-icon pairs, note headings).
- `tokens/chrome.css` — feel numbers (fade clock, opacities), grid, shadows, radii + world beats, drag shadow, the named z-ladder.
- `tokens/typography.css` — font stacks (incl. `--ew-font-editor`) + chrome and editor type scales.
- `tokens/editor-face.css` — the Maple Mono @font-face rules (bundled).
- `assets/seed/` — 6 seed artworks + license. `assets/fonts/` — Maple Mono woff2 ×3 + OFL. `assets/icons/` — the 6 object-icon SVG masters.
- `guidelines/` — foundation specimen cards (Design System tab): doctrine, colors ×5, type ×2, icons, stage/void, paper materials, the note lifecycle, frame region, motion beats, z-ladder, note links, tooltip shapes.
- `components/` — chrome/ controls/ panels/ board/ feedback/ (see cards).
- `STYLE-GUIDE.md` — the visual system + ■ TECH build contract, one page.

### Components

- **chrome/**: `Charm` (rail charm button), `CharmRail` (⧉ ⌕ ⊛ ⊞ ▤ ☰ + ⚠ perch), `Dock` (floating tool dock), `PathBar` (entry-route crumbs + bookmark teardrop), `MenuPopover` (anchored menu rows w/ shortcuts, sections, deferred), `TooltipChip` (the one tooltip style).
- **controls/**: `Button` (default/accent/ghost), `Segmented` (pill segments), `FacetChip` (filter pills + active-tag ✕ form), `SearchTrack` (the ratified five-state search control: icon → bar → AND-ing pills → melt), `TextInput` (never datalist), `TagChip` (#tag mono, paper/dark habitats).
- **panels/**: `Panel` (screen-space shell), `NotePanel` (the note lifecycle: open book ⇄ sticky ⇄ landmark, 3 binding edges incl. top for wide images; identical corner controls), `NoteHeading` (loud colored h1–h3 + [...] fold marker), `WikiLink` (bound/unresolved/trashed/broken — broken is STRIKETHROUGH), `NoteMetaCard` (the §7.8 system block: placements tree + fly-to, provenance, per-note toggle), `Paper` (the bare sheet), `Tape`, `TornEdge` (side + top tears), `BinderRings` (side + top strips), `GlossyPin` (pin control ON), `PushPin` (the landmark's hardware).
- **board/**: `NodeCard` (placed node: flat, hint charms, selected/hit/dimmed), `HintCharm` (drawn page/frame), `CharmBar` (selection charm bar ⌗ ⇋ ⇵ | make-canvas note # ⊘), `ObjectIcon` (the six object icons, dot-degrading), `Frame` (THE grouping: drawn region, title + sort chip on the top edge, drag-hover focus).
- **feedback/** (all in Toast.jsx): `Toast` (base/error/success), `ActionBar` (bulk-select bar), `ModeSwitcher` (⊛ ▤ ⊞ takeover switcher), `ImportProgressStrip` (never modal), `RecognitionChip` (transient offer chip) — plus `MultiDropAsk` (the §6.8 multi-drop modal: Keep separate · Sort · Group · Group & sort, remember).
- **Shared input primitives (registry lead):** `TextInput` + `Button` are THE set — TagPanel, SearchPanel, RestoreDialog, SettingsView must consume them, not hand-roll the look from raw tokens.
- `ui_kits/desktop/` — interactive recreation of the app's core screens, one file per surface:
  - `index.html` — the board: the full note lifecycle (open the chief's note, tear it out, pin it through), the wide-image page opening BELOW (open Northern Reach's note), the frame w/ hover-dim, right-click item + board menus, the multi-drop ask (board menu → Paste), the search lens w/ track, the impact confirm. Doors out: expand → big editor, zoom− → the void, rail ⊞ → gallery, ☰ → settings/trash.
  - `gallery.html` — the takeover at the canonical control set: scope, facet row w/ search track + cleanup facets + size slider, bucketed time w/ jump header, Space preview (press Space!), import strip + action bar on one axis, the everything-scope rules.
  - `settings.html` — the sheet over the live board; theme/grid clicks repaint in place; backups, keyboard registry, connectors, Advanced → AI.
  - `trash.html` — archive-tone rows, restore + fly-there toast, Empty trash confirm, Help/About (plain type, no logo).
  - `editor.html` — the centered torn-off page (modal-rung): Maple outliner w/ click-to-fold headings, selection toolbar, all four link states.
  - `first-run.html` — the seven guide pages (EPIC-019 final copy), taped-paper voice.
  - `void.html` — the lit stage and the void; drag the outlying item and the edge follows, eased.
- `_src/` — v1 extracted artifacts · `_src/v2-docs/` — the Design-Artifacts v2.0 documents — reference only, not shipped.

## Design-pass amendments (2026-07-06/07 — ratified into this package; see Design-Team-Letter-1.md for the full log)

This package now TRACKS Design-Artifacts v2.0 at RFC rev 0.54. The amendments below are landed in the tokens, components, guidelines, and UI kit — not just described:

- **Doctrine (ratified):** "chrome is a terminal; the world is a desk." Chrome stays flat mono per the rules above; WORLD content carries gentle materiality — object node icons (`guidelines/icons-objects.html`), taped paper notes with torn edges when pinned, the red glossy pin ON the paper (never in chrome). See `guidelines/doctrine.html`.
- **Motion corollary:** "fades and single pulses only" now governs CHROME. World content is allowed small one-shot physical beats — pin tear-off (~300ms), first-placement bloom, eased stage growth. One beat per user act; never ambient, never looping.
- **Editor typeface carve-out:** note text is **Maple Mono** (bundled at `assets/fonts/`, OFL, true italics) — the one exception to "no webfonts." Chrome stays system stacks. Colored, loud heading levels; org-style outliner presentation over the Markdown carrier. See `guidelines/type-editor.html`.
- **Icons:** the six node icons are designed and MASTERED (`assets/icons/obj-*.svg`, `ObjectIcon` component); they degrade to the plain dot below ~8px rendered size. Dot palette regularization proposed, not yet ratified (`guidelines/colors-node-dots-proposed.html`).
- **Broken links strike through** — red-wavy retired (read as spell-check); every link state names itself with the one tooltip chip on hover.
- **The named z-ladder** (§8.8): `--ew-z-*` rungs world 0 → tooltip 800; names normative; the centered torn-off note is a MODAL-rung tenant with a scrim. See `guidelines/z-ladder.html`.
- **Frame region** (AI-IMP-127): furniture, not art — `--ew-frame-fill/-border/-label`, hex-only; title ON the top edge, zoom-gated. See `guidelines/frame-region.html`.
- **Floating things cast shadows**: `--ew-drag-shadow` exactly while something rides a drag or mid-tear.
- **The note lifecycle** (Note Lifecycle Document, 2026-07-07, → RFC §8.5 amendments; `guidelines/note-lifecycle.html`): three states, freely reversible — open book ⇄ sticky ⇄ landmark; hardware tells the state (rings · tape · push pin); **shadow = viewport-floating ONLY** (supersedes "screen-space panels carry shadow" — the landmark is flat); the binding side follows the image's shape (wide ≳1.4:1 opens below, calendar-style); the torn edge persists — the page remembers.
- **The §7.8 metadata card** (rev 0.51): system-owned, structured, never raw text — `NoteMetaCard`.
- **Frames ratified** (rev 0.54, §6.8): THE grouping, single-parent nesting, geometry immunity; hover-focus-dims-board; per-frame sort-on-drop; the multi-drop ask — `Frame` + `MultiDropAsk`.
- **The lit stage and the void** (rev 0.50): `guidelines/stage-void.html`. Void = derived color-mix step, dimmed grid, soft edge; OFF on glass.
- **Tooltip grammar:** five legal shapes only (`guidelines/tooltip-shapes.html`).
- **Charm rail position:** starts BELOW the traffic-lights/path track, top-aligned with the content-panel line — it never shares the top track.
- **Settings:** section headings carry trailing fold carets; Advanced is one toggle revealing "enable connector store" → nested "AI connectors"; git push is native, other storage arrives as connectors; project-tier rows wear a "this world" chip.
- **Gallery:** the search track (icon → bar → AND-ing pills → double-click melts back to text), thumbnail-size slider, inbox + low-quality cleanup facets, Space = Quick-Look preview, import strip centered above the action bar.
- **The signature pin pass (2026-07-07, Signature Pin Changes — letter amendments #6–8):**
  - **The shell eats the window:** frameless on every platform; the board paints edge-to-edge; traffic lights drawn into the board. The hover-revealed title strip — a smoky near-black gradient, not a bar — IS the drag handle.
  - **The canonical pin is silhouette iv** — sweeping concave sides, soft rounded tip, carved-red meridian head (`assets/icons/pin-canonical.svg`). It replaces the flat 50/50/50/0 teardrop wherever pins mean places.
  - **The signature spot:** the path-tail bookmark is the app's only bookmark control — the pin lives there at cap-height beside the board name, the ONE colored element in the mono chrome, the single sanctioned chrome→world crossover. Specimen: `guidelines/pin-signature.html`.
  - **The bookmark beat:** anticipation wiggle (±8° about the tip) → 10px hop with a whisper of stretch → press, reseating exactly — ~700ms, one-shot, entirely inside the strip band. Unpin is a plain fade.
  - **Menu grammar ratified — the cascade:** every menu/popover opens rows fading in staggered ~30ms top→bottom, opacity-only, ≤190ms ease-out, anchored to its opener (`MenuPopover` to adopt). Bookmark rows wear small globes — every saved place is a world.
  - **App icon crowned:** the world-photo reference card, cross-angled, pinned by the canonical red pin (`assets/icons/app-icon.svg`; App Icon Document 5a).


## The lifecycle push (2026-07-10/11 — pending merge to 1.3; drawn rulings in expanding-worlds-lifecycles.zip)

Nine documents ratified by owner read; each is a drawn specimen page with file:line grounding. The kit-facing deltas:

- **GR-1 · the three-state rule:** every finding surface draws loading · error · empty-true · empty-filtered as distinct quiet sentences (SourcePanel's `.state` form canonized — muted ink, 0.9/0.8rem padding). Error swaps ink to `--ew-danger` + ONE retry Button. **No spinners, ever** — loading is a static sentence; determinate work rides ImportProgressStrip; <~150ms shows nothing. Plumbing strings never speak. Persistent failure moves to the ⚠ perch.
- **GR-2 · the exit rule:** the 8-rung Escape ladder is law (gesture → editor → menu/ask → lens → panel → selection → **sticky tool → select** (new) → takeover/overlay). Every transient has THREE exits: Escape, one visible pointer exit, click-away (universal; panels exempt — they are workspaces). Timer-only dismissal forbidden (RecognitionChip gains a ✕). Leaving cleans up everything provisional. Disabled-forever controls retired: inert + why-tooltip (the crop card-button idiom) replaces native `disabled` in charm bars.
- **GR-3 · the silence budget:** seven outcome classes, one voice each — succeeded-visible = silence · succeeded-elsewhere = toast naming where · app-decided = fact toast (only when the app chose) · failed-with-surface = inline sentence · failed-without = error toast (fact then reassurance) · ongoing condition = ⚠ perch · routine echo = sanctioned silence. Failure is never silent. Quit-time/background outcomes report at next open.
- **GR-4 · the trust grammar:** one gesture = one undo group, sized to the act; undo restores the selection too; restore joins structural undo; purge honestly never does; impact-as-fact confirms ratified.
- **Tooltip grammar amendment:** armed sticky tools append the exit clause — "Pin N · esc returns to select".
- **The ⊡ birth glyph (B1):** leads the new-board naming palette, the charm bar, and the frame hint charm — a board's birth is never framed with note vocabulary (¶).
- **The provisional pin (S3):** the canonical pin as a 45% ghost, tip on the click point; commit = 180ms press to seated; discard = plain fade. The generic provisional dot is retired. Full bookmark ceremony stays exclusive to the signature spot.
- **The remove gesture (T2):** a tag chip in a remove-capable habitat (note meta strip, tag panel carrier rows) grows the FacetChip ✕ on hover; removal is silent, ⌘Z restores. Filter-✕ and removal-✕ never share a habitat.
- **The ask prints its default (A1/GR-2 R4):** MultiDropAsk gains the contract line — "esc or walking away lands them separate".

### The motion ledger (beats promoted — axis grammar new)

**Axis grammar: zoom = depth · slide = siblings · fade = takeovers.** Navigation into/out of nesting is always the zoom; lateral moves (history back/forward, bookmark jumps) are a restrained parallax slide; takeovers fade. One motion vocabulary, selector to deepest board.

| beat | trigger | shape | duration |
|---|---|---|---|
| the dive | entering a board (both birth doors, frame charm) | camera flight THROUGH the object — it fills and fades; never a crossfade | 240ms ease-out |
| the surfacing | leaving a board / End Session | the dive reversed — world recedes into its cover/object | 240ms ease-out |
| the carry | palette birth, pull-into-world | object rides the cursor (finger on glass); seating click commits | until seated |
| the seat | pin commit | 45% ghost → full, one press | 180ms |
| the bookmark beat | pinning the signature spot | wiggle ±8° → 10px hop → press (EXCLUSIVE to the path-tail) | ~700ms one-shot |
| the burn | trash (world content leaves) | the surfaces-document burn — one-shot, world-side | ~300ms |
| pin tear-off / bloom | note tear, first placement | existing world beats, unchanged | ~300ms |
| the cascade | every menu/popover | rows stagger ~30ms, opacity-only | ≤190ms |

## Caveats / intentional notes

- Values marked `~` in STYLE-GUIDE.md are provisional numbers awaiting build confirmation (editor scale, beat durations, note heading hues, drag shadow).
- `--ew-void-surface` is runtime-derived in the app (from the EFFECTIVE board color); here it rides `--ew-board-color`, defaulting to the dark surface.
- The UI kit screens use striped placeholders where the seeded example has no shipped art; `assets/seed/` supplies the real pieces where they exist.
- The local codebase mount disconnected partway through the v2 pass (after tokens were mirrored); nothing here was invented to fill that gap — all v2 values come from the in-project Design-Artifacts v2.0.
