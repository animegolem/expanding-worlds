# Design System kit — changelog

The kit zip supersedes IN PLACE (one tracked
`Expanding Worlds Design System <ver>.zip` + its standalone HTML);
git history keeps every prior byte, so there is no zip archive.
Each swap gets an entry here: the lead diffs the incoming version
against the outgoing one and records the delta before committing.
Ratifications still route kit → DESIGN-QUEUE → RFC rev — this file
is the version record, not the decision log.

## 1.3 — 2026-07-11 (lead-reviewed; corrections applied, ready to lock)

- **The signature pin pass absorbed** (2026-07-07 branch, produced
  parallel to 1.2 and never folded into the zip until now):
  frameless shell (the board paints edge-to-edge, hover title
  strip IS the drag handle), the canonical pin silhouette iv
  (`assets/icons/pin-canonical.svg`; flat teardrop retired
  wherever pins mean places), the signature spot (path-tail
  bookmark, the ONE colored chrome element), the bookmark beat
  (~700ms wiggle→hop→press, exclusive to the strip), the menu
  cascade (~30ms stagger, ≤190ms, `MenuPopover` to adopt), the
  crowned app icon (`assets/icons/app-icon.svg`).
- **The lifecycle push rulings landed** (expanding-worlds-
  lifecycles.zip carries the nine drawn documents; owner-read
  10–11 Jul; kit-facing deltas recorded in readme):
  - GR-1 three-state (quiet-sentence form canonized, error ≠
    empty, no spinners, sentence ledger).
  - GR-2 exit rule (8-rung Escape ladder, three exits, universal
    click-away with the panels exception, disabled-forever retired
    for inert + why-tooltip, `RecognitionChip` gains a ✕).
  - GR-3 silence budget (seven outcome classes; failure always
    speaks; report-at-return).
  - GR-4 trust grammar (one gesture one undo group; undo restores
    selection; restore captured, purge honestly not).
  - The ⊡ birth glyph · the provisional pin as 45% ghost
    (180ms seat, generic dot retired) · the T2 remove gesture
    (FacetChip ✕ in remove-capable habitats; filter-✕ and
    removal-✕ never cohabit; **R6, lead review: per-node unassign
    on mirrored content writes a narrow suppression so sync never
    re-applies what a hand removed** — tag-sync.ts 271 union)
    · `MultiDropAsk` prints its default
    · armed sticky tools append the tooltip exit clause.
  - **Lead-review corrections (11 jul):** GR-4 R1/R5 scoped to
    user gestures (system writes — sync, migrations, repairs —
    live outside the ledger by design); P2's drawn ritual carries
    the push-tags step (main/index.ts:1241); GR-3 status header
    fixed; iPad ledger gained its P2+P5+P1 row; B1 R6 flagged for
    cross-check vs 271 cross-canvas undo semantics at RFC routing.
    This file's tracked copy at RAG/design/KIT-CHANGELOG.md is the
    only real one — the bundle copy is a convenience mirror.
- **The motion ledger promoted with an axis grammar**: zoom =
  depth (the dive, through-the-object, 240ms; reversed for
  End Session's surfacing) · slide = siblings (history/bookmark
  jumps, restrained parallax) · fade = takeovers. New rows: dive ·
  surfacing · carry · seat · burn (the surfaces-document trash
  burn, ~300ms world-side one-shot) · cascade. Full table in
  readme; specimen pages to follow as `motion/` guidelines.
- **Companion documents now tracked beside the kit**: the iPad
  port delta (live ledger — scrim-for-Escape, rest-for-hover, the
  eighth outcome class "done here, not yet real") and the
  lifecycle sequencing map. Per-surface desktop/iPad UI kits and
  the linking storyboard are the next phase.
- Sources of authority unchanged: current RFC > letters > kit.
  Ratification into an RFC rev routes via DESIGN-QUEUE after the
  in-context lead-dev review.

## 1.2 — 2026-07-07

- **The "One voice" control-geometry ruling** (answers the
  AI-IMP-142 consolidation finding): inputs keep exactly TWO
  variants as grammar — pill (999) = typing filters-in-place
  (search, tags, facets) · standard (5px) = typing configures
  (settings, dialogs, rename). Buttons collapse to ONE geometry —
  5px radius · 1px `--ew-border-control` · raised surface · hover
  lightens one step · disabled .4 — color variants riding it; the
  4px dialog and 6px variants retire by mechanical sweep. Focus is
  UNIFORM: 2px `--ew-focus-ring` outline, offset 1px, on every
  field and control — never the browser default (paper habitats
  keep `--ew-paper-border-focus`). Stragglers (CharmRail source
  prompt, gallery facets/action bar) migrate in a follow-up; the
  guard allowlist then shrinks to zero and becomes absolute.
- `Button.jsx`/`TextInput.jsx` reference components updated to the
  ruled shapes (5px, focus ring, disabled .4); STYLE-GUIDE §4
  carries the ruling; readme records it. Tokens unchanged.

## 1.1 — 2026-07-07

- **The beat ledger formalized** (from The Two Materials):
  `chrome.css` gains the full constant set — lift 120 · settle 150
  · nudge 40 · cover/tuck 200 · away 180 · glide-max 300 ·
  lift/press scale ±1% · strain 2px — plus the no-beat list and
  shrink-ladder constants; STYLE-GUIDE §6 rewritten as the
  every-mouse-down ledger with the honest-metaphor rule. New
  `guidelines/motion-beats.html`; kit re-verified against RFC rev
  0.55. Ratified into the RFC at rev 0.56.
- New `Design Kit Overview.html` + standalone kit page.

## 1.0 — 2026-07-07 (baseline)

- First kit: verbatim token mirror + additions (obj gradients,
  tape/torn paper, note headings, drag shadow), 23 reference
  components, guidelines set, six object-icon SVG masters, Maple
  Mono woff2 + OFL, ui-kit screens, adherence config, STYLE-GUIDE
  with ■ TECH build contracts. Ratified into the RFC at rev 0.55.
