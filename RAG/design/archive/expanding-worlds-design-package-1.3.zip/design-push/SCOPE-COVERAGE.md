# Scope coverage — RFC + design folder vs the kit push

*Session close-out audit, 2026-07-12. Everything graded against
RFC-0001 (rev ~0.48+), DESIGN-GAPS, the lifecycle kit (GR-1..4 + this
session's GR-5), and the kit-cutting order from SURFACE-REVIEW.*

## Covered — kit + grammar + preflight shipped

- **Home canvas** (§8.1/8.2/8.8): reservation frame + charm halo,
  dock family (defaults row 1d, shape flyout 2a, beta-native sweep),
  contained signature spot + real PinGlyph, ❖ board menu (3 doors),
  identity corner ◎ (6b), color picker + eyedropper, lens via tags
  charm. Arrange ⌗ ruling in grammar (5a) — panel NOT yet wired.
- **Outliner ▤** (§14.1): kit v1.1 (untagged facet, calm badges,
  editable-empty note, context menu) + grammar; retrofitted to the
  frame + rail. Debt: reading-flight verb in preview; preflight unfilled.
- **Gallery ⊞** (§14.4 in-project): 1.2 sweep kit + short grammar;
  arrange-by-carries-grouping ruled.
- **Graph ⊛** (§14.2): first drawing ever — force physics, wiki-only
  edges, LOD, orphan rings, filters. Preflight filled.
- **Search ⌕** (§8.3): centered palette (RFC delta flagged), kind-verb
  headers, tag pills. Preflight filled; grammar page not written.
- **Menu ☰**: app-level MenuPopover kit (not a takeover).
- **Note paper** (§8.5 rev 0.55): four postures live, hardware law,
  open-as-flight, zoom ruler; unblocks AI-IMP-194.
- **Cross-cutting**: GR-5 touch dialect (§1–4 ruled, §5–6 proposals),
  Motion Ledger (10 beats incl. delete/burn), KIT-PREFLIGHT system,
  DESIGN-LETTER (18 rulings + addenda), pin/globe unification.

## Ratified elsewhere — no kit owed

- Settings document (ratified; adoption tickets exist) · app icon 5a ·
  pin & menu motion prototype · Two Materials doctrine.

## MISSES — surfaces the kits point at but nobody has drawn

1. **Tag panel (§4.8)** — the biggest: search results, chip clicks,
   and charm verbs all route here ("opens the tag panel"); it has a
   ruled grammar (search field + completion, result rows spanning
   canvases) and no drawing. Next kit, first.
2. **Trash view (§9)** — the recovery home; menu row + GR-4's
   trash-is-recovery contract depend on it. Includes the burn beat's
   only home (Empty Trash confirm).
3. **Bookmark menu** — motion prototype ratified; kit still owed,
   including #07's globes-for-dots rows.
4. **⚠ condition panel (§8.6)** — the perch renders in every kit;
   its panel is undrawn (ConditionPanel.svelte ships bare).
5. **World picker** ("switch world…") — referenced by ☰; undrawn.
6. **First-run guide** — copy final (EPIC-019); surface undrawn at
   kit fidelity; touch teaching channel (GR-5 §6) folds in.
7. **Source panel / everything scope (§14.4)** — gallery kit covers
   in-project only; the compressed source-panel form + pull flow undrawn.
8. **Centered big editor (§8.5)** — described in paper grammar,
   posture not built.
9. **Caption card (§4.5 captions)** — DESIGN-GAPS item, still open.
10. **Wired-but-ruled gaps**: arrange ⌗ panel (5a), selection restyle
    charm panel (1c), outliner reading-flight verb — rulings exist,
    wiring pending the click-through shell.

## Suggested order for the next session

tag panel → trash view (+ burn confirm) → bookmark menu → condition
panel → source panel/everything scope → first-run + caption card →
click-through shell stitching (lens + fly beats become real).
