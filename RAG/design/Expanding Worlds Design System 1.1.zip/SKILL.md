---
name: expanding-worlds-design
description: Use this skill to generate well-branded interfaces and assets for Expanding Worlds (the art-first, recursive reference-board desktop app), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

Precedence: RFC > STYLE-GUIDE.md (the ■ TECH blocks are the build contract) > README.md. The doctrine in one line: chrome is a terminal (flat, mono-flavored, unicode glyphs, one shared fade clock); the world is a desk (object icons, taped paper notes, one-shot physical beats). Every color is an `--ew-*` token from `tokens/` before use; note text is Maple Mono (bundled in `assets/fonts/`), chrome is system stacks; never the word "file" in copy.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view — link `styles.css` for the tokens and start from the `ui_kits/desktop/` screens and `components/` primitives. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
