The chrome button — THE shared small-button primitive (registry lead: TagPanel, SearchPanel, RestoreDialog, and SettingsView must use this, not hand-rolled lookalikes).

```jsx
<Button onClick={fn}>Restore</Button>
<Button variant="accent">Add to library</Button>
<Button variant="ghost">not now</Button>
<Button disabled>Empty Trash</Button>
```

- Raised surface, 1px control border, 6px radius; hover lightens one surface step; disabled rests at 0.4.
- `accent` = the committed/primary act; `ghost` = borderless quiet act.
- Danger styling is per-use: pass `style={{ color: 'var(--ew-danger-muted)', borderColor: 'var(--ew-danger-border)' }}` — only destructive verbs wear it.
