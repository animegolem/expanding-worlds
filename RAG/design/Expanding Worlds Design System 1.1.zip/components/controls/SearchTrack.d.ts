/** The search track — icon → bar → committed terms crystallize into
 * pills (AND, booru-style); trailing ✕ clears all; double-click melts
 * pills back to text; empty collapses to the icon (Gallery t3,
 * ratified). */
export interface SearchTrackProps {
  /** Committed pill terms (controlled). Tags start with #. */
  pills?: string[];
  onChange?: (pills: string[]) => void;
  placeholder?: string;
  /** Tag completions shown while typing #… */
  suggestions?: { tag: string; count: number }[];
  /** Track width when expanded */
  width?: number | string;
  style?: React.CSSProperties;
}
