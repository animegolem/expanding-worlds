import React from 'react';

/** The search track (Gallery Document t3, ratified): five states of
 * one control. rest (⌕ icon) → click → bar → typing (completions) →
 * ⏎ crystallizes committed terms into pills (AND, booru-style) →
 * double-click melts pills back to editable text. Trailing ✕ clears
 * all; empty collapses back to the icon. Tag pills wear the note
 * accent; plain-text terms stay neutral. Fully controlled OR
 * self-managing (uncontrolled) — pass `pills`/`onChange` to control. */
export function SearchTrack({
  pills: pillsProp,
  onChange,
  placeholder = '',
  suggestions = [],
  width = 230,
  style,
}) {
  const [own, setOwn] = React.useState([]);
  const pills = pillsProp ?? own;
  const set = (next) => { onChange ? onChange(next) : setOwn(next); };
  const [state, setState] = React.useState(pills.length ? 'pills' : 'rest'); // rest | bar | pills
  const [text, setText] = React.useState('');
  const inputRef = React.useRef(null);

  const commit = () => {
    const terms = text.trim().split(/\s+/).filter(Boolean);
    if (terms.length) {
      set([...pills, ...terms]);
      setText('');
      setState('pills');
    }
  };
  const clearAll = () => { set([]); setText(''); setState('rest'); };
  const removePill = (i) => {
    const next = pills.filter((_, j) => j !== i);
    set(next);
    if (!next.length) setState('rest');
  };
  const melt = () => {
    setText([...pills, text.trim()].filter(Boolean).join(' '));
    set([]);
    setState('bar');
    setTimeout(() => inputRef.current && inputRef.current.focus(), 0);
  };

  if (state === 'rest' && !pills.length) {
    return (
      <button
        type="button"
        title="Search"
        onClick={() => { setState('bar'); setTimeout(() => inputRef.current && inputRef.current.focus(), 0); }}
        style={{ width: 24, height: 24, borderRadius: 5, background: 'var(--ew-control-tint)', border: '1px solid var(--ew-border-strong)', color: 'var(--ew-text-muted)', fontSize: 11, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: 0, ...style }}
      >⌕</button>
    );
  }

  const showSuggestions = state === 'bar' && text.startsWith('#') && suggestions.length > 0;
  return (
    <span style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', gap: 5, width, border: `1px solid ${state === 'bar' ? 'var(--ew-accent)' : 'var(--ew-border-strong)'}`, borderRadius: 5, padding: '2.5px 7px', background: 'var(--ew-surface-input)', fontFamily: 'var(--ew-font-ui)', fontSize: '0.72rem', color: 'var(--ew-text)', boxSizing: 'border-box', ...style }}>
      <span style={{ color: 'var(--ew-text-muted)', flex: 'none' }}>⌕</span>
      {state === 'pills' ? (
        <>
          <span onDoubleClick={melt} title="Double-click to edit" style={{ display: 'inline-flex', gap: 4, flexWrap: 'nowrap', overflow: 'hidden', cursor: 'text' }}>
            {pills.map((p, i) => (
              <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, border: `1px solid ${p.startsWith('#') ? 'var(--ew-node-dot-orange)' : 'var(--ew-border-control)'}`, borderRadius: 999, padding: '0 7px', color: p.startsWith('#') ? 'var(--ew-node-dot-orange)' : 'var(--ew-text)', fontFamily: 'var(--ew-font-mono)', fontSize: '0.68rem', whiteSpace: 'nowrap' }}>
                {p}
                <span onClick={(e) => { e.stopPropagation(); removePill(i); }} style={{ color: 'var(--ew-text-subtle)', cursor: 'pointer' }}>✕</span>
              </span>
            ))}
          </span>
          <span style={{ flex: 1 }}></span>
          <span onClick={clearAll} title="Clear search" style={{ color: 'var(--ew-text-subtle)', cursor: 'pointer', flex: 'none' }}>✕</span>
        </>
      ) : (
        <input
          ref={inputRef}
          value={text}
          placeholder={placeholder}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') commit();
            else if (e.key === 'Escape') { if (!text && !pills.length) setState('rest'); else { setText(''); if (pills.length) setState('pills'); } }
            else if (e.key === 'Backspace' && !text && pills.length) removePill(pills.length - 1);
          }}
          onBlur={() => { if (!text && pills.length) setState('pills'); else if (!text && !pills.length) setState('rest'); }}
          style={{ flex: 1, minWidth: 40, border: 'none', outline: 'none', background: 'transparent', color: 'inherit', font: 'inherit', padding: 0 }}
        />
      )}
      {showSuggestions && (
        <span style={{ position: 'absolute', left: 20, top: '100%', marginTop: 4, background: 'var(--ew-surface-menu)', border: '1px solid var(--ew-border)', borderRadius: 4, padding: '2px 6px', fontFamily: 'var(--ew-font-mono)', fontSize: '0.68rem', color: 'var(--ew-text-muted)', whiteSpace: 'nowrap', zIndex: 'var(--ew-z-popover)', boxShadow: 'var(--ew-panel-shadow-menu)' }}>
          {suggestions.filter((s) => s.tag.startsWith(text)).slice(0, 3).map((s) => (
            <span key={s.tag} onMouseDown={(e) => { e.preventDefault(); set([...pills, s.tag]); setText(''); setState('pills'); }} style={{ marginRight: 8, cursor: 'pointer' }}>{s.tag} · {s.count}</span>
          ))}
        </span>
      )}
    </span>
  );
}
