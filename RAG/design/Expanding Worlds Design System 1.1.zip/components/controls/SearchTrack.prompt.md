The gallery/board search track — one control with five states (rest icon → bar → typing → pills → melt); committed terms AND together, tags wear the warm accent.

```jsx
<SearchTrack
  pills={['#creature', 'gob']}
  onChange={setPills}
  suggestions={[{ tag: '#creature', count: 41 }, { tag: '#crescent-keep', count: 3 }]}
/>
```

- Uncontrolled if you omit `pills`/`onChange` — it manages its own state.
- ⏎ crystallizes typed terms into pills; double-click a pill run to melt back to editable text; trailing ✕ clears all; clearing the last pill collapses the track to the ⌕ icon.
- The grid it filters should thin live at every state.
