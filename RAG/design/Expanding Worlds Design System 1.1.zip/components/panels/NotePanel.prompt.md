The paper note panel across the note lifecycle — `variant="bound"` beside/below an image (match the shared edge), `variant="sticky"` for pages torn onto the glass, `variant="landmark"` for push-pinned board placements, default tethered for the legacy glance.

```jsx
<NotePanel variant="bound" title="Goblin chief" tags={['goblin']} places={3} height={240}
           onPin={tearOut} onExpand={openBigEditor} />          {/* portrait: side seam, height = image's */}
<NotePanel variant="bound" bindEdge="top" width={260} …/>       {/* wide image: opens below, width = image's */}
<NotePanel variant="sticky" homeBoard="northern reach" onHome={flyHome} …/>
<NotePanel variant="landmark" width={220} …/>                   {/* flat — a real placement */}
```

- Hardware tells the state: rings · tape + glass shadow · push pin. The torn edge persists once torn; every transition reverses, one undo each.
- Corner controls identical on every variant: ⌖ places · pin · ⤢ (no ✕ — esc/click-off closes).
- Body is the editor face (Maple Mono); `NoteHeading level={1|2|3}` for loud colored headings (`folded` shows `[...]`).
- `WikiLink` states: bound (blue) · unresolved (purple) · trashed (grey) · broken (red strikethrough).
- Put a `NoteMetaCard` after the body children for the §7.8 system block.
