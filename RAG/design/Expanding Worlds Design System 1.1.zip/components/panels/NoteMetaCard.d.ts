/** The §7.8 system metadata card — the system-owned block at a note's
 * tail, rendered as a structured card below the editor, never raw
 * text. */
export interface NoteMetaCardProps {
  /** Placements tree grouped by board, respecting board nesting */
  placements?: PlacementEntry[];
  /** Image-backed nodes: original filename, import date, source, connector */
  provenance?: { filename: string; imported?: string; source?: string; connector?: string };
  /** Default OFF per the v1 registry */
  timestamps?: { created: string; modified?: string };
  /** The per-note toggle state; false renders the quiet off-seam */
  enabled?: boolean;
  onToggle?: () => void;
  /** Fly-to — every placements entry is a navigation target */
  onFly?: (entry: PlacementEntry) => void;
  style?: React.CSSProperties;
}
export interface PlacementEntry {
  board: string;
  count: number;
  children?: PlacementEntry[];
}
