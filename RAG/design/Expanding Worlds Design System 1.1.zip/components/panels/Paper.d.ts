/** Paper materials — the bare Paper sheet plus Tape, TornEdge,
 * BinderRings, GlossyPin, PushPin. World-content materiality for
 * notes (the doctrine + the Note Lifecycle Document). Hardware tells
 * the state: rings = bound · tape = sticky · push pin = landmark. */
export interface PaperProps {
  /** Which marks the sheet carries: bound = rings · sticky = tape +
   * tear + glass shadow · landmark = push pin + tear, FLAT.
   * 'pinned' is a legacy alias for sticky. */
  variant?: 'tethered' | 'bound' | 'sticky' | 'pinned' | 'landmark';
  /** The binding/tear edge. Wide images (≳1.4:1) bind on top. */
  bindEdge?: 'left' | 'right' | 'top';
  width?: number | string;
  height?: number | string;
  ringCount?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export interface TapeProps {
  width?: number;
  height?: number;
  /** Rotation in degrees */
  angle?: number;
  style?: React.CSSProperties;
}
export interface TornEdgeProps {
  /** Which edge carries the tear — the former binding edge. The scar
   * records where it was bound and persists once torn. */
  edge?: 'left' | 'right' | 'top';
  style?: React.CSSProperties;
}
export interface BinderRingsProps {
  /** The binding seam edge; 'top' runs the strip across the page top */
  edge?: 'left' | 'right' | 'top';
  count?: number;
  /** Ring diameter px (~11) */
  ring?: number;
  style?: React.CSSProperties;
}
export interface GlossyPinProps {
  size?: number;
  title?: string;
  style?: React.CSSProperties;
}
export interface PushPinProps {
  size?: number;
  title?: string;
  style?: React.CSSProperties;
}
