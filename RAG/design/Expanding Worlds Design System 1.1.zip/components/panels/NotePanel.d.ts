/** Note panel — the note lifecycle (Note Lifecycle Document → RFC
 * §8.5): open book ⇄ sticky on the glass ⇄ landmark in the world.
 * Hardware tells the state; the torn edge is the scar that stays. */
export interface NotePanelProps {
  title?: string;
  /** Subject node's tags (zero-node notes show none) */
  tags?: string[];
  /** ⌖ n places header fact */
  places?: number;
  /** tethered (legacy glance) · bound (the open book — matches the
   * shared edge exactly) · sticky (torn + taped to the glass, travels;
   * alias 'pinned') · landmark (push-pinned placement, flat, world) */
  variant?: 'tethered' | 'bound' | 'sticky' | 'pinned' | 'landmark';
  /** Back-compat alias for variant="sticky" */
  pinned?: boolean;
  /** Origin board label when the subject node is on another board */
  origin?: string;
  /** Sticky footer chip naming the home board — shows when the page
   * travels; click flies home */
  homeBoard?: string;
  /** Unsaved dot */
  dirty?: boolean;
  width?: number | string;
  /** REQUIRED for side-bound: exactly the image's height */
  height?: number | string;
  /** The binding/tear edge — the side facing the image. Wide images
   * (≳1.4:1) bind on top: the page opens BELOW, width = image width */
  bindEdge?: 'left' | 'right' | 'top';
  children?: React.ReactNode;
  /** The pin control: tear out (bound→sticky) / plant or tuck home */
  onPin?: () => void;
  /** ⤢ — the taught door to the big editor */
  onExpand?: () => void;
  onClose?: () => void;
  onPlaces?: () => void;
  /** Home-chip click (sticky) — flies to the home board */
  onHome?: () => void;
  style?: React.CSSProperties;
}
