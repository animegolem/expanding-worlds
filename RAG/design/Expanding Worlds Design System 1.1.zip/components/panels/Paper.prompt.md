Paper materials — Paper, Tape, TornEdge, BinderRings, GlossyPin, PushPin — the note lifecycle's hardware; compose them onto paper sheets (NotePanel does this for you via its variants).

```jsx
<Paper variant="bound" bindEdge="left" height={240}>…</Paper>     {/* rings on the seam */}
<Paper variant="sticky" bindEdge="top" width={220}>…</Paper>      {/* tape + tear + glass shadow */}
<Paper variant="landmark" width={220}>…</Paper>                   {/* push pin, FLAT — world content */}
```

- Hardware tells the state: rings (bound) · tape + shadow (sticky on the glass) · push pin (landmark in the world). The torn edge is the one scar that stays.
- Shadow = viewport-floating ONLY: sticky carries it; the landmark renders flat like every placement.
- `bindEdge="top"` is the wide image's calendar binding — rings/tear run across the top, tape goes to a side.
- The red object pin appears exactly three ways, all ON paper: the pin control's ON state (GlossyPin), the landmark's PushPin, and the big editor's header pin.
