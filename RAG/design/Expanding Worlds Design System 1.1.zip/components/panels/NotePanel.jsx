import React from 'react';
import { TagChip } from '../controls/TagChip.jsx';
import { BinderRings, Tape, TornEdge, GlossyPin, PushPin } from './Paper.jsx';

/** Note panel — the note lifecycle (Note Lifecycle Document, → RFC
 * §8.5): three states, freely reversible; hardware tells the state.
 *
 * - `bound` — the open book: affixed beside (or below) its image,
 *   matching the SHARED edge exactly — image height when side-bound,
 *   image width when top-bound (wide images ≳1.4:1 open below like a
 *   calendar). Rings on the seam. Scales with the world.
 * - `sticky` — torn out, taped to the GLASS: tape + torn edge +
 *   viewport shadow; travels across boards; a home chip names its
 *   board when the picture is far. (Alias: pinned.)
 * - `landmark` — push-pinned INTO the board: a real placement, FLAT
 *   (shadow is the glass's cue, not the world's), scales with the
 *   world. The push pin does the saying.
 * - `tethered` — the legacy glance form (dashed tail drawn by host).
 *
 * The torn edge persists once torn. Corner controls are IDENTICAL
 * everywhere: ⌖ places · pin · ⤢ expand. Every arrow runs both ways,
 * one undo each. */
export function NotePanel({
  title,
  tags = [],
  places = 1,
  variant,
  pinned,
  origin,
  homeBoard,
  dirty,
  width = 340,
  height,
  bindEdge = 'left',
  children,
  onPin,
  onExpand,
  onClose,
  onPlaces,
  onHome,
  style,
}) {
  const v = variant === 'pinned' ? 'sticky' : variant || (pinned ? 'sticky' : 'tethered');
  const isSticky = v === 'sticky';
  const isBound = v === 'bound';
  const isLandmark = v === 'landmark';
  const topBound = bindEdge === 'top';
  const seamRadius = topBound ? '0 0 9px 9px' : bindEdge === 'right' ? '9px 0 0 9px' : '0 9px 9px 0';
  const ringCount = topBound
    ? Math.max(3, Math.round((typeof width === 'number' ? width : 340) / 78))
    : Math.max(3, Math.round((typeof height === 'number' ? height : 300) / 72));
  return (
    <div
      style={{
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        width,
        height,
        boxSizing: 'border-box',
        background: 'var(--ew-paper-surface)',
        border: `1px solid ${isSticky ? 'var(--ew-paper-pinned-border)' : 'var(--ew-paper-border-strong)'}`,
        borderRadius: isBound ? seamRadius : isLandmark ? 'var(--ew-node-radius)' : isSticky ? 6 : 9,
        boxShadow: isSticky ? 'var(--ew-panel-shadow-pinned)' : isLandmark ? 'none' : 'var(--ew-panel-shadow)',
        fontFamily: 'var(--ew-font-ui)',
        ...style,
      }}
    >
      {isBound && <BinderRings edge={bindEdge} count={ringCount} />}
      {(isSticky || isLandmark) && <TornEdge edge={bindEdge} />}
      {isSticky && (topBound
        ? <Tape style={{ position: 'absolute', left: -13, top: '50%', marginTop: -8, transform: 'rotate(88deg)' }} />
        : <Tape style={{ position: 'absolute', top: -7, left: '50%', marginLeft: -23 }} />)}
      {isLandmark && <PushPin size={17} title="Planted — pull the pin to take it back onto the glass" style={{ position: 'absolute', left: '50%', top: -9, transform: 'translateX(-50%)', zIndex: 1 }} />}
      <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden', borderRadius: 'inherit' }}>
        <header style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', padding: `${isLandmark ? '0.55rem' : '0.4rem'} 0.45rem 0.25rem`, cursor: isSticky ? 'grab' : 'default' }}>
          {origin && (
            <span style={{ flex: 'none', maxWidth: '9rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', padding: '0.05rem 0.4rem', border: '1px solid var(--ew-paper-info-border)', borderRadius: 9, background: 'var(--ew-paper-info-panel)', color: 'var(--ew-paper-info-text)', fontSize: '0.7rem', cursor: 'pointer' }}>⌂ {origin}</span>
          )}
          <h2 style={{ flex: 1, margin: 0, overflow: 'hidden', fontSize: '0.85rem', fontWeight: 600, color: 'var(--ew-paper-text-heading)', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {title}
            {dirty && <span style={{ marginLeft: '0.3rem', color: 'var(--ew-paper-dirty)', fontSize: '0.6rem', verticalAlign: 'middle' }}>●</span>}
          </h2>
          <button type="button" onClick={onPlaces} style={paperBtn} title={`${places} places`}>⌖ {places} {places === 1 ? 'place' : 'places'}</button>
          {onPin && !isLandmark && (
            <button type="button" onClick={onPin} style={{ ...paperBtn, display: 'inline-flex', alignItems: 'center' }} title={isSticky ? 'On your glass · pin through to plant it, or dismiss to tuck it home' : 'Tear it onto your glass'}>
              {isSticky ? (
                <GlossyPin size={15} />
              ) : (
                <span style={{ display: 'inline-block', width: 9, height: 9, margin: '0 2px 1px 0', border: '1.5px solid var(--ew-paper-text-muted)', borderRadius: '50% 50% 50% 0', transform: 'rotate(-45deg)', boxSizing: 'border-box' }}></span>
              )}
            </button>
          )}
          {onExpand && <button type="button" onClick={onExpand} style={paperBtn} title="Open big editor">⤢</button>}
          {onClose && <button type="button" onClick={onClose} style={paperBtn} title="Close">✕</button>}
        </header>
        {tags.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.25rem', padding: '0 0.55rem 0.3rem' }}>
            {tags.map((t) => <TagChip key={t} tag={t} on="paper" />)}
          </div>
        )}
        <div style={{ flex: 1, minHeight: 0, overflow: 'auto', background: 'var(--ew-paper-page)', color: 'var(--ew-paper-text)', padding: '0.5rem 0.65rem', fontFamily: 'var(--ew-font-editor)', fontSize: 'var(--ew-editor-body)', lineHeight: 1.65 }}>
          {children}
        </div>
        {isSticky && homeBoard && (
          <button type="button" onClick={onHome} title="Fly home" style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '0.25rem 0.6rem', border: 'none', borderTop: '1px solid var(--ew-paper-border-subtle)', background: 'var(--ew-paper-surface)', color: 'var(--ew-paper-info-text)', fontFamily: 'var(--ew-font-editor)', fontSize: '0.68rem', cursor: 'pointer', textAlign: 'left', borderRadius: '0 0 6px 6px' }}>
            ▸ {homeBoard}
          </button>
        )}
      </div>
    </div>
  );
}

const paperBtn = {
  flex: 'none',
  padding: '0 0.3rem',
  border: 'none',
  background: 'transparent',
  font: 'inherit',
  fontSize: '0.72rem',
  color: 'var(--ew-paper-text-muted)',
  cursor: 'pointer',
  whiteSpace: 'nowrap',
};

/** LOUD note heading (EPIC-018 values): size AND color at a glance,
 * riding --ew-note-h1/2/3. Use inside note bodies only. `folded` shows
 * the org-style [...] fold marker after the text. */
export function NoteHeading({ level = 1, folded, children, style }) {
  const l = Math.min(3, Math.max(1, level));
  return (
    <div style={{ fontFamily: 'var(--ew-font-editor)', fontWeight: 700, fontSize: `var(--ew-editor-h${l})`, color: `var(--ew-note-h${l})`, margin: '0.35em 0 0.15em', ...style }}>
      {children}
      {folded && <span style={{ opacity: 0.55, fontWeight: 400, marginLeft: '0.4em', fontSize: '0.85em' }}>[...]</span>}
    </div>
  );
}

/** Wiki-link span for note bodies: bound blue · unresolved purple ·
 * trashed grey (recoverable) · broken red STRIKETHROUGH (purged —
 * wavy retired at t6: it read as spell-check). Every state carries
 * the one tooltip chip on hover; states never rely on color alone. */
export function WikiLink({ state = 'bound', title, children }) {
  const color = state === 'trashed' ? 'var(--ew-link-muted)' : `var(--ew-link-${state})`;
  const deco = state === 'broken' ? 'line-through' : 'underline';
  const decoColor = state === 'trashed' ? 'var(--ew-link-muted)' : `var(--ew-link-${state}-decoration)`;
  return (
    <span title={title} style={{ color, textDecoration: deco, textDecorationColor: decoColor, textUnderlineOffset: 2, cursor: 'pointer' }}>{children}</span>
  );
}
