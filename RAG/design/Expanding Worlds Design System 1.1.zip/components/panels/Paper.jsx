import React from 'react';

/** Paper materials (the doctrine + the Note Lifecycle Document):
 * the marks hardware leaves on a page — tape, the torn edge, binder
 * rings, the glossy pin control, the push pin. World content: gentle
 * materiality that survives light/dark/glass via the --ew-tape-* /
 * --ew-paper-torn tokens. Hardware tells the state: rings = bound ·
 * tape (+shadow) = sticky on the glass · push pin = landmark in the
 * world. The torn edge is the one scar that stays. */

/** The bare paper sheet — the material every note form is made of.
 * Composes the marks by variant: bound adds rings, sticky adds tape +
 * torn edge, landmark adds the push pin + torn edge (flat — shadow is
 * the glass's, not the world's). NotePanel builds on this; use Paper
 * directly for custom paper surfaces (first-run cards, gallery text
 * posts). */
export function Paper({ variant = 'tethered', bindEdge = 'left', width, height, ringCount = 5, children, style }) {
  const isSticky = variant === 'sticky' || variant === 'pinned';
  const isBound = variant === 'bound';
  const isLandmark = variant === 'landmark';
  const seamRadius = bindEdge === 'top' ? '0 0 9px 9px' : bindEdge === 'right' ? '9px 0 0 9px' : '0 9px 9px 0';
  return (
    <div
      style={{
        position: 'relative',
        width,
        height,
        boxSizing: 'border-box',
        background: 'var(--ew-paper-surface)',
        border: `1px solid ${isSticky ? 'var(--ew-paper-pinned-border)' : 'var(--ew-paper-border-strong)'}`,
        borderRadius: isBound ? seamRadius : isLandmark ? 'var(--ew-node-radius)' : isSticky ? 6 : 9,
        boxShadow: isSticky ? 'var(--ew-panel-shadow-pinned)' : isLandmark ? 'none' : 'var(--ew-panel-shadow)',
        ...style,
      }}
    >
      {isBound && <BinderRings edge={bindEdge} count={ringCount} />}
      {(isSticky || isLandmark) && <TornEdge edge={bindEdge} />}
      {isSticky && (bindEdge === 'top'
        ? <Tape style={{ position: 'absolute', left: -13, top: '50%', marginTop: -8, transform: 'rotate(88deg)' }} />
        : <Tape style={{ position: 'absolute', top: -7, left: '50%', marginLeft: -23 }} />)}
      {isLandmark && <PushPin size={17} style={{ position: 'absolute', left: '50%', top: -9, transform: 'translateX(-50%)' }} />}
      {children}
    </div>
  );
}

/** A strip of translucent tape. Place absolutely over a panel edge. */
export function Tape({ width = 46, height = 15, angle = -4, style }) {
  return (
    <span
      aria-hidden="true"
      style={{
        display: 'inline-block',
        width,
        height,
        background: 'var(--ew-tape-surface)',
        border: '1px solid var(--ew-tape-border)',
        borderRadius: 1,
        transform: `rotate(${angle}deg)`,
        boxSizing: 'border-box',
        ...style,
      }}
    ></span>
  );
}

/* Ragged silhouettes, reused. Side tear: x pairs are [outer, inner]
 * steps. Top tear: the same rhythm rotated. */
const TORN_SIDE = '100% 0%, 100% 100%, 55% 100%, 20% 96%, 68% 91%, 28% 85%, 60% 79%, 15% 72%, 55% 66%, 30% 60%, 70% 53%, 22% 46%, 58% 40%, 12% 33%, 62% 27%, 25% 20%, 65% 13%, 18% 7%, 52% 0%';
const TORN_TOP = '0% 100%, 4% 0%, 10% 80%, 17% 10%, 24% 95%, 31% 20%, 38% 90%, 45% 5%, 52% 100%, 59% 15%, 66% 85%, 73% 10%, 80% 95%, 87% 20%, 94% 80%, 100% 100%';

/** The torn edge — the ragged strip left where the page tore out of
 * its binding. Hangs just outside the former binding edge; the scar
 * records WHERE it was bound (top-torn vs side-torn pages read
 * differently), and it persists once torn. */
export function TornEdge({ edge = 'left', style }) {
  if (edge === 'top')
    return (
      <span
        aria-hidden="true"
        style={{ position: 'absolute', left: 0, right: 0, top: -5, height: 6, background: 'var(--ew-paper-torn)', clipPath: `polygon(${TORN_TOP})`, ...style }}
      ></span>
    );
  const flip = edge === 'right';
  return (
    <span
      aria-hidden="true"
      style={{
        position: 'absolute',
        top: 0,
        bottom: 0,
        [flip ? 'right' : 'left']: -7,
        width: 8,
        background: 'var(--ew-paper-torn)',
        clipPath: `polygon(${TORN_SIDE})`,
        transform: flip ? 'scaleX(-1)' : 'none',
        filter: 'drop-shadow(-1px 0 0 var(--ew-paper-border))',
        ...style,
      }}
    ></span>
  );
}

/** Binder rings straddling the seam of the bound page (~11px, 2px
 * stroke, punched — the fill is the board color showing through).
 * edge='top' runs the strip across the page top (the wide image's
 * calendar binding); left/right run it down the side. */
export function BinderRings({ edge = 'left', count = 5, ring = 11, style }) {
  const horizontal = edge === 'top';
  const flip = edge === 'right';
  const ringEl = (i) => (
    <span
      key={i}
      style={{
        width: ring,
        height: ring,
        borderRadius: '50%',
        border: '2px solid var(--ew-text-muted)',
        background: 'var(--ew-board-color, var(--ew-surface-solid))',
        boxSizing: 'border-box',
        flex: 'none',
      }}
    ></span>
  );
  if (horizontal)
    return (
      <span aria-hidden="true" style={{ position: 'absolute', left: 10, right: 10, top: -(ring / 2 + 1), height: ring, display: 'flex', justifyContent: 'space-between', alignItems: 'center', ...style }}>
        {Array.from({ length: count }).map((_, i) => ringEl(i))}
      </span>
    );
  return (
    <span
      aria-hidden="true"
      style={{ position: 'absolute', top: 10, bottom: 10, [flip ? 'right' : 'left']: -(ring / 2 + 1), width: ring, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', alignItems: 'center', ...style }}
    >
      {Array.from({ length: count }).map((_, i) => ringEl(i))}
    </span>
  );
}

/** The red glossy pin — the panel pin CONTROL in its ON state. One of
 * exactly three appearances of the red object pin, all ON paper.
 * Chrome pin instances (path-tail bookmark, dock ◉) stay the flat
 * teardrop. */
export function GlossyPin({ size = 15, title, style }) {
  const gid = React.useId();
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={style} role={title ? 'img' : undefined} aria-label={title}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="var(--ew-obj-red-hi)" />
          <stop offset="1" stopColor="var(--ew-obj-red-lo)" />
        </linearGradient>
      </defs>
      <path d="M12 3.2a7.3 7.3 0 0 1 7.3 7.3c0 2.1-1 3.7-2.6 5.3L12 21l-4.7-5.2C5.7 14.2 4.7 12.6 4.7 10.5A7.3 7.3 0 0 1 12 3.2z" fill={`url(#${gid})`} stroke="var(--ew-obj-red-stroke)" strokeWidth=".8" />
      <ellipse cx="9.6" cy="6.8" rx="2.6" ry="1.4" fill="var(--ew-obj-gloss)" />
    </svg>
  );
}

/** The push pin — the landmark's hardware (Note Lifecycle beat 6):
 * a glossy red ball head on a metal stem, pushed through the page
 * into the board. Straddle it over the page's former binding edge. */
export function PushPin({ size = 17, title, style }) {
  const gid = React.useId();
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={style} role={title ? 'img' : undefined} aria-label={title}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="var(--ew-obj-red-hi)" />
          <stop offset="1" stopColor="var(--ew-obj-red-lo)" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="9" r="6.5" fill={`url(#${gid})`} stroke="var(--ew-obj-red-stroke)" strokeWidth=".8" />
      <ellipse cx="9.8" cy="6.6" rx="2.4" ry="1.4" fill="var(--ew-obj-gloss)" />
      <path d="M12 15.5v5" stroke="var(--ew-pushpin-stem)" strokeWidth="1.6" />
    </svg>
  );
}
