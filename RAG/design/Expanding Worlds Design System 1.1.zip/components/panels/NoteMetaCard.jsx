import React from 'react';

/** The system metadata card (RFC §7.8, rev 0.51) — the system-owned
 * block at a note body's tail, rendered as a STRUCTURED CARD below
 * the editor, never raw text. Visibly system, not prose: the info-
 * panel palette, mono micro-type, a labeled seam. Sections from the
 * fixed v1 registry: Placements (tree grouped by board, respecting
 * nesting; every entry a fly-to), Provenance (original filename,
 * import date, source, importing connector), Timestamps (default
 * OFF). Per-note toggle at the seam; in-app display always computes
 * live. */

function PlacementRow({ node, depth, onFly }) {
  const [open, setOpen] = React.useState(depth < 1); // deep trees fold: top level open, rest folded — 40 boards stay scannable
  const kids = node.children || [];
  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, paddingLeft: depth * 12 }}>
        {kids.length > 0 ? (
          <button type="button" onClick={() => setOpen(!open)} style={{ ...bare, width: 10, color: 'var(--ew-paper-info-text)' }}>{open ? '▾' : '▸'}</button>
        ) : (
          <span style={{ width: 10, flex: 'none' }}></span>
        )}
        <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{node.board}</span>
        <span style={{ opacity: 0.7 }}>· {node.count}</span>
        <button type="button" title={`Fly to ${node.board}`} onClick={onFly ? () => onFly(node) : undefined} style={{ ...bare, color: 'var(--ew-link-bound)' }}>⌖ fly</button>
      </div>
      {open && kids.map((k) => <PlacementRow key={k.board} node={k} depth={depth + 1} onFly={onFly} />)}
    </>
  );
}

export function NoteMetaCard({ placements = [], provenance, timestamps, enabled = true, onToggle, onFly, style }) {
  if (!enabled)
    return (
      <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--ew-font-mono)', fontSize: '0.62rem', color: 'var(--ew-paper-text-soft)', ...style }}>
        <span style={{ flex: 1, borderTop: '1px dashed var(--ew-paper-border)' }}></span>
        metadata off for this note
        {onToggle && <button type="button" onClick={onToggle} style={{ ...bare, color: 'var(--ew-paper-info-text)' }}>turn on</button>}
      </div>
    );
  return (
    <div style={{ marginTop: 14, borderRadius: 6, background: 'var(--ew-paper-info-panel)', border: '1px solid var(--ew-paper-info-border)', fontFamily: 'var(--ew-font-mono)', fontSize: '0.66rem', lineHeight: 1.9, color: 'var(--ew-paper-info-text)', ...style }}>
      {/* the seam: visibly system-owned, not prose */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderBottom: '1px solid var(--ew-paper-info-border)' }}>
        <span style={{ fontWeight: 700, fontSize: '0.58rem', letterSpacing: '.07em' }}>SYSTEM</span>
        <span style={{ fontSize: '0.6rem', opacity: 0.65 }}>kept fresh by the app — edits here don't stick</span>
        {onToggle && <button type="button" onClick={onToggle} title="Stop keeping this block on this note" style={{ ...bare, marginLeft: 'auto', opacity: 0.75 }}>✕</button>}
      </div>
      <div style={{ padding: '6px 10px 8px' }}>
        {placements.length > 0 && (
          <>
            <div style={sectionHead}>PLACEMENTS</div>
            {placements.map((p) => <PlacementRow key={p.board} node={p} depth={0} onFly={onFly} />)}
          </>
        )}
        {provenance && (
          <>
            <div style={{ ...sectionHead, marginTop: 6, paddingTop: 6, borderTop: '1px solid var(--ew-paper-info-border)' }}>PROVENANCE</div>
            <div>{provenance.filename}{provenance.imported ? ` · ${provenance.imported}` : ''}</div>
            {(provenance.source || provenance.connector) && (
              <div style={{ opacity: 0.85 }}>{provenance.source}{provenance.connector ? ` · via ${provenance.connector}` : ''}</div>
            )}
          </>
        )}
        {timestamps && (
          <>
            <div style={{ ...sectionHead, marginTop: 6, paddingTop: 6, borderTop: '1px solid var(--ew-paper-info-border)' }}>TIMESTAMPS</div>
            <div>created {timestamps.created}{timestamps.modified ? ` · modified ${timestamps.modified}` : ''}</div>
          </>
        )}
      </div>
    </div>
  );
}

const sectionHead = { fontWeight: 700, fontSize: '0.58rem', letterSpacing: '.07em' };
const bare = { border: 'none', background: 'transparent', font: 'inherit', cursor: 'pointer', padding: 0, flex: 'none' };
