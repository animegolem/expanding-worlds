The §7.8 system metadata card — put it after a note body (inside NotePanel children or the big editor) to render the system-owned Placements/Provenance/Timestamps block as a structured card, never raw text.

```jsx
<NoteMetaCard
  placements={[
    { board: 'Homeworld', count: 1 },
    { board: 'Northern Reach', count: 2, children: [{ board: 'Warren stores', count: 1 }] },
  ]}
  provenance={{ filename: 'goblin_chief_v2.png', imported: '12 jun 2026', source: 'artstation.com', connector: 'page picker' }}
  onFly={(e) => flyTo(e.board)}
  onToggle={togglePerNote}
/>
```

- The SYSTEM seam labels it visibly system-owned ("edits here don't stick" — regenerated wholesale on refresh).
- Deep trees stay scannable: top-level boards open, nested branches folded behind ▸.
- Every placements row is a fly-to target; `timestamps` is default OFF per the v1 registry — pass it only when the setting is on.
- `enabled={false}` renders the quiet off-seam with a turn-on affordance (the per-note toggle).
