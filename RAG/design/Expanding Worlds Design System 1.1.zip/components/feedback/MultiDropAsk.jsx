import React from 'react';
import { Button } from '../controls/Button.jsx';

/** The multi-drop ask (RFC §6.8, the §14.4 first-drop ask idiom):
 * on multi-drop/big-paste, a small modal asks what shape the arrivals
 * take — Keep separate · Sort · Group · Group & sort — with
 * remember-this-choice (changeable in Settings). Impact stated as
 * fact; the count is printed. Mounts at the root host (modal rung). */
export function MultiDropAsk({ count = 2, kind = 'images', remember, onRemember, onChoose, onCancel, style }) {
  const [rem, setRem] = React.useState(!!remember);
  const choose = (c) => onChoose && onChoose(c, rem);
  return (
    <div
      role="dialog"
      style={{
        width: 330,
        background: 'var(--ew-surface-modal)',
        border: '1px solid var(--ew-border-panel)',
        borderRadius: 9,
        boxShadow: 'var(--ew-panel-shadow-menu)',
        padding: '14px 16px 12px',
        fontFamily: 'var(--ew-font-ui)',
        color: 'var(--ew-text)',
        ...style,
      }}
    >
      <div style={{ fontSize: 13, fontWeight: 600 }}>{count} {kind} arriving</div>
      <div style={{ fontSize: 11.5, color: 'var(--ew-text-muted)', marginTop: 4 }}>separate {kind} — each stays its own item; a frame can hold them together</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 11 }}>
        <Button onClick={() => choose('separate')}>Keep separate</Button>
        <Button onClick={() => choose('sort')}>Sort</Button>
        <Button onClick={() => choose('group')}>Group</Button>
        <Button variant="accent" onClick={() => choose('group-sort')}>Group & sort</Button>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 11, paddingTop: 9, borderTop: '1px solid var(--ew-border)' }}>
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--ew-text-muted)', cursor: 'pointer' }}>
          <input type="checkbox" checked={rem} onChange={(e) => { setRem(e.target.checked); onRemember && onRemember(e.target.checked); }} style={{ accentColor: 'var(--ew-accent)', margin: 0 }} />
          remember this choice
        </label>
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--ew-font-mono)', fontSize: 9.5, color: 'var(--ew-text-subtle)' }}>changeable in settings</span>
        {onCancel && <button type="button" onClick={onCancel} style={{ border: 'none', background: 'transparent', color: 'var(--ew-text-muted)', font: 'inherit', fontSize: 11, cursor: 'pointer', padding: 0 }}>cancel</button>}
      </div>
    </div>
  );
}
