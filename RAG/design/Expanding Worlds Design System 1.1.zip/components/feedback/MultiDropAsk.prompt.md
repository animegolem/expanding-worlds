The multi-drop/big-paste ask — show it (modal rung, root host, over a scrim) when several items arrive at once; a big paste asks "separate images or an arranged frame."

```jsx
<MultiDropAsk count={12} kind="images"
  onChoose={(choice, remember) => applyDrop(choice, remember)}
  onCancel={dismiss} />
```

- Choices: Keep separate · Sort · Group · Group & sort (accent — the frame-shaped default).
- `remember` writes the drop-behavior setting; the footer prints "changeable in settings."
- A composite NEVER lands in the library — each image stays its own item; a composite may be saved FROM a frame on demand.
