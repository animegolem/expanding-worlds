/** The multi-drop ask modal (§6.8 / §14.4 idiom): Keep separate ·
 * Sort · Group · Group & sort, with remember-this-choice. */
export interface MultiDropAskProps {
  /** How many things are arriving — printed as fact */
  count?: number;
  /** Noun for the arrivals, e.g. 'images' | 'items' */
  kind?: string;
  /** Initial remember-checkbox state */
  remember?: boolean;
  onRemember?: (remember: boolean) => void;
  /** choice: 'separate' | 'sort' | 'group' | 'group-sort' */
  onChoose?: (choice: string, remember: boolean) => void;
  onCancel?: () => void;
  style?: React.CSSProperties;
}
