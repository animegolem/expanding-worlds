Renders one of the six node object icons (star · pin · flag · heart · bolt · leaf) — use for node appearances, the appearance-switcher popover, and anywhere a node's icon shows; it auto-degrades to the plain dot below 8px.

```jsx
<ObjectIcon icon="star" size={24} />
<ObjectIcon icon="pin" size={16} />
<ObjectIcon icon="leaf" size={6} /> {/* renders the plain green dot */}
<ObjectIcon icon="gold" dot />      {/* force the dot state */}
```

- Colors ride the `--ew-obj-*` gradient pairs (theme-independent world content); the dot state uses the matching `--ew-node-dot-*` token.
- SVG masters for the renderer's texture atlas live in `assets/icons/obj-*.svg`.
- The glossy red pin admitted into chrome adjacency (the panel pin control) is `GlossyPin` from `components/panels/Paper.jsx`, not this component.
