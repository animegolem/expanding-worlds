import React from 'react';

/** The frame (RFC §6.8, ratified rev 0.54) — THE grouping: a node
 * whose board presence is a drawn region. Furniture, not art: a
 * low-alpha wash + subtle border, the title ON the top edge (item
 * labels never are — position is the tell), a sort chip beside it
 * when sort-on-drop is on. Membership is edited only by dragging an
 * ITEM across the boundary; moving/resizing the frame never captures
 * or releases (geometry immunity). While a drag hovers the frame it
 * focuses and the REST of the board dims — dim the board in the
 * host; `focus` lights the frame side. Furniture draws only past a
 * rendered-size threshold (the charm rule). */
export function Frame({ title, sort, focus, width, height, showFurniture = true, onSort, children, style }) {
  return (
    <div style={{ position: 'relative', width, height, ...style }}>
      {showFurniture && title && (
        <span style={{ position: 'absolute', left: 2, top: -16, display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap' }}>
          <span style={{ fontFamily: 'var(--ew-font-mono)', fontSize: 10, letterSpacing: '.04em', color: 'var(--ew-frame-label)' }}>{title}</span>
          {sort && (
            <button type="button" onClick={onSort} title="Sort on drop — grid · rows · float" style={{ border: '1px solid var(--ew-frame-border)', borderRadius: 999, background: 'transparent', color: 'var(--ew-frame-label)', fontFamily: 'var(--ew-font-mono)', fontSize: 8.5, padding: '0 5px', cursor: 'pointer' }}>{sort} ▾</button>
          )}
        </span>
      )}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'var(--ew-frame-fill)',
          opacity: focus ? 0.75 : 0.5,
          border: `1px solid ${focus ? 'var(--ew-accent-soft)' : 'var(--ew-frame-border)'}`,
          borderRadius: 3,
          transition: 'opacity var(--ew-chrome-fade-ms) ease-out, border-color var(--ew-chrome-fade-ms) ease-out',
        }}
      ></div>
      {children}
    </div>
  );
}
