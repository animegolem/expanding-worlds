/** One of the six node object icons (star · pin · flag · heart · bolt ·
 * leaf) — world content: top-light gradient, restrained gloss, degrades
 * to its plain dot below ~8px rendered size. */
export interface ObjectIconProps {
  icon?: 'star' | 'pin' | 'flag' | 'heart' | 'bolt' | 'leaf';
  /** Rendered size in px; < 8 auto-degrades to the dot */
  size?: number;
  /** Force the plain-dot degrade state */
  dot?: boolean;
  title?: string;
  style?: React.CSSProperties;
}
