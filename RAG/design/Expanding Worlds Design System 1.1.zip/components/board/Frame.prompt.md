The drawn frame region — THE grouping. Wrap member NodeCards in it (absolutely positioned); the wash stays quieter than any node on it.

```jsx
<Frame title="costume studies" sort="grid" width={320} height={210} focus={isDragHover}>
  <NodeCard style={{ position: 'absolute', left: 16, top: 16 }} … />
  <NodeCard style={{ position: 'absolute', left: 120, top: 20 }} … />
</Frame>
```

- Title (and the sort-on-drop chip) sit ON the top edge in chrome type — item labels never do; position is the tell. Furniture hides below the rendered-size threshold (`showFurniture={false}`).
- `focus` is the acceptance affordance: while a drag hovers, the frame lights and the HOST dims the rest of the board.
- Frames nest single-parent; moving/resizing the frame never edits membership — only item drags across the boundary do.
- On multi-drop, show `MultiDropAsk` (feedback/) — Keep separate · Sort · Group · Group & sort, with remember.
