import React from 'react';

/** The six node object icons (Icon Document 2b family, ratified at the
 * doctrine): star · pin · flag · heart · bolt · leaf. World content —
 * top-light gradient, soft stroke, restrained gloss. Below ~8px
 * rendered size the icon degrades to its plain dot (the shrink
 * ladder). SVG masters live in assets/icons/; this component is the
 * chrome-size/live render, driven by the same --ew-obj-* tokens. */

const DOT = {
  star: 'var(--ew-node-dot-gold)',
  pin: 'var(--ew-node-dot-blue)',
  flag: 'var(--ew-node-dot-red)',
  heart: 'var(--ew-node-dot-pink)',
  bolt: 'var(--ew-node-dot-orange)',
  leaf: 'var(--ew-node-dot-green)',
};

const PAIR = { star: 'gold', pin: 'blue', flag: 'red', heart: 'pink', bolt: 'orange', leaf: 'green' };

function Shape({ icon, gid }) {
  const fill = `url(#${gid})`;
  const stroke = `var(--ew-obj-${PAIR[icon]}-stroke)`;
  const gloss = 'var(--ew-obj-gloss)';
  switch (icon) {
    case 'star':
      return (
        <>
          <path d="M12 2.5l2.8 6 6.4.6-4.8 4.3 1.4 6.3-5.8-3.3-5.8 3.3 1.4-6.3-4.8-4.3 6.4-.6z" fill={fill} stroke={stroke} strokeWidth=".8" strokeLinejoin="round" />
          <path d="M12 4.5l1.6 3.4-3.2.2z" fill={gloss} />
        </>
      );
    case 'pin':
      return (
        <>
          <path d="M12 3.2a7.3 7.3 0 0 1 7.3 7.3c0 2.1-1 3.7-2.6 5.3L12 21l-4.7-5.2C5.7 14.2 4.7 12.6 4.7 10.5A7.3 7.3 0 0 1 12 3.2z" fill={fill} stroke={stroke} strokeWidth=".8" />
          <circle cx="12" cy="10.5" r="2.6" fill="var(--ew-obj-pin-hole)" />
          <ellipse cx="9.6" cy="6.8" rx="2.6" ry="1.4" fill={gloss} />
        </>
      );
    case 'flag':
      return (
        <>
          <path d="M6 2.5h2.2v19H6z" fill="var(--ew-obj-flag-pole)" />
          <path d="M8 4h10.5l-3 3.8 3 3.8H8z" fill={fill} stroke={stroke} strokeWidth=".6" />
          <path d="M8.6 4.6h6.2l-.5.9H8.6z" fill={gloss} />
        </>
      );
    case 'heart':
      return (
        <>
          <path d="M12 20.6C6.4 16.2 3 13 3 9.6 3 7 5 5 7.4 5c1.8 0 3.4 1 4.6 2.7C13.2 6 14.8 5 16.6 5 19 5 21 7 21 9.6c0 3.4-3.4 6.6-9 11z" fill={fill} stroke={stroke} strokeWidth=".6" />
          <ellipse cx="8.4" cy="7.8" rx="2.4" ry="1.3" fill={gloss} />
        </>
      );
    case 'bolt':
      return (
        <>
          <path d="M13.5 2L4.5 13.5h5.5L9 22l9-11.5h-5.5z" fill={fill} stroke={stroke} strokeWidth=".6" strokeLinejoin="round" />
          <path d="M12.6 3.6L7.2 10.5l2.1.2z" fill={gloss} />
        </>
      );
    case 'leaf':
      return (
        <>
          <path d="M4.5 19.5C4.5 10.5 10.5 4.5 19.5 4.5c0 9-6 15-15 15z" fill={fill} stroke={stroke} strokeWidth=".6" />
          <path d="M6 18C10 14 14 10 18 6" stroke="var(--ew-obj-leaf-vein)" strokeWidth="1.2" fill="none" />
        </>
      );
    default:
      return null;
  }
}

export function ObjectIcon({ icon = 'star', size = 24, dot = false, title, style }) {
  const gid = React.useId();
  // The shrink ladder: below ~8px rendered size, swap to the plain dot.
  if (dot || size < 8) {
    const d = Math.max(4, Math.round(size * 0.66));
    return <span title={title} style={{ display: 'inline-block', width: d, height: d, borderRadius: '50%', background: DOT[icon] || 'var(--ew-node-dot-default)', ...style }}></span>;
  }
  const pair = PAIR[icon] || 'gold';
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={style} role={title ? 'img' : undefined} aria-label={title}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={`var(--ew-obj-${pair}-hi)`} />
          <stop offset="1" stopColor={`var(--ew-obj-${pair}-lo)`} />
        </linearGradient>
      </defs>
      <Shape icon={icon} gid={gid} />
    </svg>
  );
}
