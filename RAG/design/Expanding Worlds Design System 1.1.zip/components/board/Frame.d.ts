/** The frame — THE grouping (§6.8 rev 0.54): a drawn region whose
 * membership only item-drags edit. Furniture, not art. */
export interface FrameProps {
  /** Sits ON the top edge in chrome type — position is the tell */
  title?: string;
  /** Sort-on-drop mode chip beside the title: 'grid' | 'rows' | 'float' */
  sort?: string;
  /** Drag-hover acceptance state — the frame lights while the host
   * dims the rest of the board */
  focus?: boolean;
  width?: number | string;
  height?: number | string;
  /** Frame furniture draws only past a rendered-size threshold */
  showFurniture?: boolean;
  onSort?: () => void;
  /** Member placements, absolutely positioned within */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
