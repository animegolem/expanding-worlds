/* Shared shell for the desktop UI kit screens: the window frame
   (traffic lights + top edge), and the cross-screen nav conventions.
   Every screen mounts inside <AppWindow>. */

function TrafficLights() {
  return (
    <div style={{ position: 'absolute', left: 18, top: 16, display: 'flex', gap: 8, zIndex: 'var(--ew-z-chrome)' }}>
      <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#ff5f57' }}></span>
      <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#febc2e' }}></span>
      <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#28c840' }}></span>
    </div>
  );
}

/** Full-viewport app window. takeover swaps the board surface for the
   overlay surface. */
function AppWindow({ takeover, label, children, onBackdropClick }) {
  return (
    <div
      data-screen-label={label}
      style={{ position: 'relative', width: '100vw', height: '100vh', overflow: 'hidden', background: takeover ? 'var(--ew-surface-overlay)' : 'var(--ew-board-color)', fontFamily: 'var(--ew-font-ui)' }}
    >
      {!takeover && (
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'var(--ew-grid-bg)', backgroundSize: 'var(--ew-grid-size)' }} onClick={onBackdropClick}></div>
      )}
      <TrafficLights />
      {children}
    </div>
  );
}

/** Striped placeholder art block (stands in for seed images). */
function Art({ stripes = '115deg,#4a5560,#414b55', label, style }) {
  const [angle, c1, c2] = stripes.split(',');
  return (
    <div style={{ position: 'relative', background: `repeating-linear-gradient(${angle}, ${c1} 0 12px, ${c2} 12px 24px)`, ...style }}>
      {label && <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--ew-font-mono)', fontSize: 11, color: 'rgba(255,255,255,.38)' }}>{label}</span>}
    </div>
  );
}

Object.assign(window, { AppWindow, TrafficLights, Art });
