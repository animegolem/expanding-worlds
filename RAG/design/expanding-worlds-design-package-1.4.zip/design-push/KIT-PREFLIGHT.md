# KIT-PREFLIGHT — the per-kit audit checklist

Compiled once from GR-1..4, the motion-axis grammar, the iPad delta
ledger, and the reservation-frame/charm-halo invariants (Home Canvas
Grammar §1–2). Every UI kit ships three artifacts: the kit DC, its
grammar page, and this checklist filled. A ✗ with no waiver note
fails lead review.

Fill: ✓ pass · ✗ fail · — not applicable (say why).

## A · finding surfaces (GR-1)
- [ ] A1 every finding/empty surface draws its three sentences (what this is · why it's empty or shown · what to do next)
- [ ] A2 empty ≠ loading — distinct drawn states, never one doubling
- [ ] A3 error states drawn, not just happy path

## B · exits (GR-2)
- [ ] B1 every dismissible surface has ≥3 exits: esc · explicit ✕/close · click-away (or ruled exception noted)
- [ ] B2 exits land somewhere ruled — camera/selection state after exit is specified
- [ ] B3 touch: every keyboard exit has an on-screen twin

## C · outcomes & voice (GR-3)
- [ ] C1 each verb classified into one of the seven outcome classes; only the speaking classes toast
- [ ] C2 silence budget respected — no toast for silent classes, no silent mutation for speaking ones
- [ ] C3 copy: sentence case, no "file", verbs over nouns, impact stated as fact

## D · gesture-undo (GR-4)
- [ ] D1 every mutating gesture the surface owns maps to single-step undo
- [ ] D2 composite verbs (create-and-attach etc.) commit as ONE undoable command
- [ ] D3 undo answers with its named beat

## E · motion ledger
- [ ] E1 every animated transition uses a named beat from the ledger (no ad-hoc motion)
- [ ] E2 fades/pulses only, ease-out 120–240ms, no loops/bounces
- [ ] E3 all chrome fades on the one shared clock

## F · integration edges (reservation frame + charm halo)
- [ ] F1 surface clamps inside the reservation frame + 24px gutter (all four bands)
- [ ] F2 clearance measured against charm HALOS, not card edges
- [ ] F3 edges specimen shipped: surface over live board, selected node + charms, reservations tinted, at rest/hover/engaged
- [ ] F4 defaults-row growth accounted for (dock band 64→112) if the surface coexists with an armed tool

## G · one-voice geometry (kit 1.2/1.3)
- [ ] G1 radii/borders/shadows from the token tiers; no local geometry
- [ ] G2 controls are kit components — no native select/color/number/datalist
- [ ] G3 anchored surfaces grow from their opener (one-physics), pointer/anchor honest

## H · iPad delta
- [ ] H1 44px targets at touch density; density switch is one token, not per-surface forks
- [ ] H2 no hover-gated affordance without a touch synonym (long-press = context menu; tooltips have a touch teaching channel)
- [ ] H3 strip band = 0 on touch; surface still reachable

---

# Filled: Home Canvas UI Kit (2026-07-12)

A1 ✓ (board's own empty state = first-run seeding, drawn in kit's
  empty variant — the takeovers it hosts carry their own)
A2 ✓ A3 ✓ (toast + perch split per GR-3)
B1 ✓ flyout: esc / release-outside / pick · defaults row: disarm tool ·
  panels inherit  B2 ✓ (exits leave camera untouched)  B3 ✓ (touch twins:
  long-press flyout, tap-away)
C1 ✓ arm/pick = quiet classes, face answers; make-canvas/stash speak
C2 ✓ C3 ✓
D1 ✓ D2 ✓ (shape draw = one command incl. defaults)  D3 ✓
E1 ✓ (flyout uses panel-arrive; no new motion invented)  E2 ✓ E3 ✓
F1 ✓ F2 ✓ F3 ✓ (kit DC, showReservations prop + selected node w/ charm
  bar)  F4 ✓ (row drawn, band growth specified)
G1 ✓ G2 ✓ (picker-list/stepper/swatches replace the beta natives)
G3 ✓ (flyout centers on armed slot w/ pointer)
H1 ✓ via density token (kit shows desktop; touch delta in grammar §1)
H2 ✓ H3 ✓ (strip=0; path bar persists at touch, drag handle unneeded)


---

# Filled: Note Paper UI Kit (2026-07-12)

A1 ✓ (phantom/empty drafts carry their own three sentences — shipped
  flows retained; kit shows populated states)  A2 — (no async load in
  kit scope)  A3 ✓ (conflict/error flows stay per shipped panel)
B1 ✓ reading flight: esc / ✕ / ground-click all return · places
  popover: esc / tap-away  B2 ✓ (flight restores camera exactly)
B3 ✓ (✕ twin for esc; long-press = context menu per GR-5)
C1 ✓ posture transitions speak once (tear/tape/pin/rebind beats);
  flight is silent (camera answers)  C2 ✓  C3 ✓ ("from:" caption,
  no "file", sentence case)
D1 ✓ D2 ✓ one undo per lifecycle transition (ruled, doc: "one undo
  each")  D3 ✓ beats name themselves
E1 ✓ tear ~300 / settle ~240 from the ledger; flight 240ms ease-out
E2 ✓ one-shot, no loops  E3 — (no resident chrome fades in kit scope)
F1 ✓ taped page clamps inside frame; state chip + toast in bands
F2 ✓ (whisper strip inside page bounds; no charm halo collision —
  demo image's charms noted as debt below)  F3 △ edges specimen with
  rail+dock+charms NOT in this kit — home canvas kit carries it;
  paper kit shows postures in isolation. flagged.  F4 —
G1 ✓ radii/shadow tiers; paper tokens  G2 ✓ (no natives)  G3 ✓
  (places popover grows from its verb)
H1 △ verb strip at rest is small; touch density pass deferred with
  the app-wide density token  H2 ✓ (long-press menu carries the verb
  inventory)  H3 —

Debts: F3 edges specimen · H1 density pass · zoom-ruler specimen not
yet drawn IN the kit (wireframe 2a is the reference) · centered
editor posture described, not built.


---

# Filled: Gallery UI Kit (2026-07-12)

A1 ✓ (empty-scope vocabulary rule: empty, never stale)  A2 ✓ (scope-
  ready gate is the shipped pattern)  A3 ✓ (bulk summary toast carries
  failures)
B1 ✓ (esc/✕/ground-click; completion list tap-away)  B2 ✓  B3 ✓
C1 ✓ bulk verbs = ONE summary toast; facet toggles silent  C2 ✓
C3 ✓ (sentence case, "items", browse-only hint copy)
D1 ✓ D2 ✓ (bulk trash/tag = one undo group, ruled + shipped)  D3 ✓
E1 ✓ (no new motion; takeover swap in place)  E2 ✓ E3 —
F1 ✓ sheet clamps to reservation frame + gutter; rail visible
F2 — (no board nodes under the takeover in kit scope)  F3 △ shares
  home-canvas edges specimen (takeover-over-board drawn there)  F4 —
G1 ✓ G2 ✓ (Segmented/FacetChip/TextInput/Button — zero locals; the
  1.2 straggler sweep is the kit's whole point)  G3 ✓ (completions
  grow from the field; action bar from the selection)
H1 △ chips ~24px — grows with the app-wide density token  H2 ✓
H3 ✓ (takeover reachable from rail; no strip dependency)

Debts: H1 density pass · F3 shared specimen · grouping thresholds
(name ~24) want tester validation.


---

# Filled: Search UI Kit (2026-07-12)

A1 ✓ rest state teaches (what it covers, # for tags, esc); no-match
  says WHY (trash excluded) and what next (fewer letters, drop a pill)
A2 — (no async in kit scope)  A3 ✓
B1 ✓ esc · scrim tap-away · rail ⌕ toggles  B2 ✓ "the board is
  exactly as you left it"  B3 ✓ (scrim tap is the touch twin)
C1 ✓ ↵ verbs answer per kind; dismissal beats once  C2 ✓ C3 ✓
  (headers name verbs in sentence case, "items", no "file")
D1 — (search mutates nothing)  D2 — D3 —
E1 ✓ (palette uses panel-arrive; no new motion)  E2 ✓ E3 —
F1 ✓ palette top aligns to the rail band; clamps viewport - 160
F2 — F3 △ shares home-canvas edges specimen  F4 —
G1 ✓ menu-tier geometry; mono meta  G2 ✓ (custom list, never
  datalist; plain input styled to kit — flag: should become the DS
  TextInput bare variant when one exists)  G3 △ centered palette is a
  RULED exception to grow-from-opener: the keyboard summons it, and
  rail-⌕ is the second door to the same surface (supersedes §8.3's
  anchored panel — needs lead cosign, recorded in wireframes + letter)
H1 △ rows ~30px — density token  H2 ✓ H3 ✓

Debts: G3 cosign · H1 · G2 input variant · multi-tag deferral note
(pills are the recorded booru shape; the §4.8 deferral stands).


---

# Filled: Graph UI Kit (2026-07-12)

A1 ✓ (empty filter result leaves the physics field — worth a drawn
  empty state when a real filter zeroes; flagged)  A2 — A3 ✓
B1 ✓ esc via takeover · rail swap  B2 ✓  B3 ✓ (drag IS touch; tap
  = activate)
C1 ✓ activation beats (fly + lens ring / note panel); filters silent
C2 ✓ C3 ✓
D1 — (graph mutates nothing; drag is view physics)  D2 — D3 —
E1 ✓ physics is world-motion, not chrome; settles, never loops
  ambiently at rest? — the force sim idles asymptotically; flag for
  the lead: does a settled graph count as "no ambient motion"?  E2 ✓
E3 —
F1 ✓ sheet clamps to frame; rail visible  F2 — F3 △ shared specimen
F4 —
G1 ✓ G2 ✓ (FacetChips/ModeSwitcher; canvas is content, not chrome)
G3 ✓
H1 △ density token · H2 ✓ (hover tooltip has tap equivalent: tap
  selects+names before second tap activates — NOT yet wired; debt)
H3 ✓

Debts: zero-result empty state · settled-sim vs ambient-motion ruling ·
tap-to-name touch step · single-tag filter is hardcoded #region in
the kit (real one takes the tag panel's pick).


---

# Filled: Tag Panel UI Kit (2026-07-12 — lead-ordered, leads next build)

A1 ✓ (empty tag result would show count 0 + scope line; drawn state
  debt noted)  A2 — A3 ✓
B1 ✓ esc drops the LENS first, panel second (exit ladder) · ✕ · doors
B2 ✓ (camera untouched; lens is view state)  B3 ✓
C1 ✓ fly/open beats; lens toggle silent (visible state IS the answer)
C2 ✓ C3 ✓ (sentence case; "no places — loose" in warn ink)
D1 — (panel mutates nothing in Phase 1; assign rides the add-field)
D2 — D3 —
E1 ✓ lens dim 240ms ease-out; no new motion  E2 ✓ E3 —
F1 ✓ panel clamps left band; board visible for the lens  F2 — F3 △
  shared specimen  F4 —
G1 ✓ G2 ✓ (TagChip/CharmRail; custom completion, never datalist)
G3 ✓ (three doors, one surface — §4.8 verbatim)
H1 △ rows ~44px already close; density token  H2 ✓ (rows are taps;
  lens toggle is a button)  H3 ✓

Debts: zero-result drawn state · drag-out affordance on placeable
rows only (lead cosign #5) · multi-tag = backend unlock (recorded).


---

# Filled: Menu UI Kit (2026-07-13 — kit 1.4, gates 293)

A1 ✓ (menu is never empty; deferred rows say why in-place)  A2 — A3 ✓
B1 ✓ esc · click-away · second press of ☰  B2 ✓ (board untouched)
B3 ✓ (tap-away)
C1 ✓ rows that leave answer at destination; export speaks (fix
  recorded: export row beats its outcome, never silent)  C2 ✓ C3 ✓
D1 — D2 — D3 — (menu mutates nothing)
E1 ✓ panel-arrive only  E2 ✓ E3 ✓
F1 ✓ grows from ☰; clamps strip band (46)  F2 — F3 △ shared  F4 —
G1 ✓ menu-tier geometry  G2 ✓  G3 ✓ (anchored to opener)
H1 △ rows via density token  H2 ✓ (long-press = same menu)  H3 ✓
  (☰ moves to strip per 293; touch keeps it on the rail foot)

# Filled: Outliner UI Kit (2026-07-13 — kit 1.4, gates 293)

A1 ✓ empty outline teaches (what it lists · why empty · make one)
A2 ✓ A3 ✓ (BROKEN-ARC rows wear warn ink + repair verb)
B1 ✓ esc · ✕ · rail ▤ toggles  B2 ✓ camera preserved; reading
  flight returns  B3 ✓
C1 ✓ reading-flight verb beats; rename commits silent (visible)
C2 ✓ C3 ✓ (filename fallback rendered mono, never "file")
D1 ✓ rename/stash single-step  D2 ✓ D3 ✓
E1 ✓ fold uses the shared clock; flight = camera ease  E2 ✓ E3 ✓
F1 ✓ takeover clamps the frame + gutter  F2 ✓ F3 △ shared  F4 —
G1 ✓ G2 ✓ (tag field custom completion)  G3 ✓
H1 △ 44px rows at touch  H2 ✓ (long-press = row menu)  H3 ✓
Debt: caption-as-row-meta lands after lead executes RFC 0.71 wording.

# Filled: Caption Card UI Kit (2026-07-13 — kit 1.4, gates 297)

A1 ✓ (uncaptioned = no card; ❝ names itself)  A2 — A3 ✓ (empty
  commit = nothing persists, beat says so)
B1 ✓ esc cancels draft · enter commits · click-away cancels  B2 ✓
B3 ✓ (touch: ❝ charm; keyboard-free path complete)
C1 ✓ commit speaks once; edit re-enters silently  C2 ✓ C3 ✓
D1 ✓ one undo per commit  D2 ✓ (caption rides the placement)  D3 ✓
E1 ✓ pop = one-shot 280ms ease-out (ledger: plaque-birth)  E2 ✓ E3 —
F1 — (board content, not chrome)  F2 ✓ plaque sits INSIDE the halo
  math (bottom furniture)  F3 ✓ this kit is the specimen  F4 —
G1 ✓ plaque geometry is content-side (paper material rules)  G2 ✓
G3 ✓ (card grows from its print)  H1 ✓ 44px ❝  H2 ✓ H3 ✓
Debt: ❝ slot on DS CharmBar (component amendment, recorded).

# Filled: Settings UI Kit (2026-07-13 — kit 1.4, gates 300)

A1 ✓ header teaches the no-save model  A2 — A3 ✓ (glass fallback
  named in its beat)
B1 ✓ esc · ✕ · click-away  B2 ✓ (sheet over board; board untouched)
B3 ✓  C1 ✓ commits-on-change speak only where invisible (theme/
  density visible = silent; board paint speaks)  C2 ✓ C3 ✓
D1 ✓ every control single-step reversible by re-setting  D2 — D3 ✓
E1 ✓ toggle knob 120ms; fold on shared clock  E2 ✓ E3 ✓
F1 ✓ inset sheet respects all four bands  F2 — F3 △ shared  F4 —
G1 ✓ G2 ✓ (Segmented/toggles/swatches — zero natives)  G3 ✓
H1 ✓ density IS the setting (auto/compact/comfortable)  H2 ✓ H3 ✓
