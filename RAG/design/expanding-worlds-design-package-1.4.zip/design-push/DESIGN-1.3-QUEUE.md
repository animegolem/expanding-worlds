# Design kit 1.3 — correction queue

*Captured from the code lead's one-object review + frame-wave round 1
(2026-07-12). Ordered by when EPIC-029 needs each item. This is the
work list for the NEXT design session; nothing here blocks phase A.*

## Needed for phases A–B (soonest)

1. **Eyedropper glyph master** — 289 ships the tool; needs a drawn
   master in the object-icon family (the kit already uses an SVG
   pipette — promote/redraw it as the canonical asset, retire ⊙
   everywhere it lingers). The one genuinely blocking drawing.
2. **Reservation tokens ADDED to kit chrome.css** (round-1 correction:
   they were never added, not awaiting promotion): --ew-reserve-strip /
   -rail / -dock / -dock-expanded / -gutter. In doing so RULE the strip
   value — the kit self-conflicts (DC specimen 40 vs Home Canvas
   Grammar 46); shipped app is 46 and phase A encodes 46 until 1.3
   speaks. Recommendation: ratify 46 (adoption never retunes feel).
3. **Arrange ⌗ panel** — wired in Home Canvas kit late in 1.13 (four
   named sections, clamped, single-selection demo); 1.3 adds a true
   multi-select demo board so the panel is exercised as ruled.
4. **Edges specimen with a node AT the frame edge** — charm-bar
   clamping shown, not just specified; 287 measures the halo envelope
   off it.
5. **Search-input bare variant ruling** — 288 is building the input
   family: rule whether a bare variant joins the two-variant grammar
   or the palette adopts pill.
6. **Charm-halo envelope drawn unambiguously** (round-1 correction):
   wireframe 1b reads card+12 all sides; shipped furniture is
   BOTTOM-ONLY charm expansion. 1.3 draws which sides carry charm
   height and the rule for future furniture on other sides. Code
   follows measured furniture meanwhile.

## Before phase C/D tickets cut (preflight waiver terms)

7. Preflights filled: Selection Transform (→291) · Caption Card
   (→297) · Settings (→300) · Menu (→292) · Outliner (→293). Tag
   panel done in 1.1; Trash/Bookmark/Condition/World Picker/Source
   Panel/First Run/Big Editor wait — EPIC-029 doesn't consume them.
8. Note Paper debts (→296): F3 edges specimen + zoom-ruler specimen
   drawn IN the kit (wireframe 2a is the reference today). Centered-
   editor posture + density pass stay deferred.

## Ratified by round 1 (no design action; recorded)

- strip initializes at shipped 46 for phase A
- density semantics: compact = desktop · comfortable = touch, strip 0
- halo = bottom-only charm expansion, measured off real furniture
- feel-dial dev-seam pattern supersedes the ticket's suggestion
- 12-native guard allowlist ratified as enumerated
- phase A ships against 1.2 + rulings; 1.3 value changes are
  one-token follow-ups, never mid-wave retargets


---

# Status — resolved in kit 1.4 (2026-07-13)

1 eyedropper master ✓ (assets/eyedropper.svg) · 2 tokens added, strip
ruled 46 ✓ · 3 multi-select arrange demo ✓ (Home Canvas kit) · 4 edge
specimen ✓ (node at the rail band, charm bar clamps) · 5 bare variant
ruled ✓ (scoped third variant, letter 37) · 6 halo drawn ✓ (bottom-
only charm height, letter 36) · 7 preflights: Menu/Outliner/Caption/
Settings ✓ (remainder wait per waiver) · 8 note-paper debts ✓.
